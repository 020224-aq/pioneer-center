// 只读:查看 pc_ 前缀表结构(先锋中心采购相关)
const mysql = require('mysql2/promise');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.MYSQL_HOST || 'your-mysql-host.example.com',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'YOUR_DB_USER',
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DB || 'YOUR_DATABASE',
  });
  const [tables] = await conn.query(
    `SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND (TABLE_NAME LIKE 'pc\\_%' OR TABLE_NAME LIKE '\\_\\_new\\_pc%')`
  );
  console.log('=== pc_ 相关表 ===');
  for (const t of tables) {
    const [cols] = await conn.query(
      `SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_COMMENT
       FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
       ORDER BY ORDINAL_POSITION`, [t.TABLE_NAME]);
    console.log(`\n■ ${t.TABLE_NAME}`);
    for (const c of cols) {
      console.log(`  ${c.COLUMN_NAME}  ${c.COLUMN_TYPE}  ${c.IS_NULLABLE === 'NO' ? 'NOT NULL' : ''}  ${c.COLUMN_COMMENT || ''}`);
    }
  }
  await conn.end();
})().catch(e => { console.error('ERR:', e.message); process.exit(1); });
