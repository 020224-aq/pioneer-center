# 先锋中心 · 采购资源中枢系统(框架版)

> 当前为**框架版本**:前后端骨架 + SQLite 数据库 + 种子数据(基于 2026/9 真实业务文档)。
> 待同事的开屏动画/视觉设计、四大板块内容设计完成后,由安琪统一发回整合。

## 快速启动

```bash
node server.js
```

打开 http://localhost:5173 (默认端口 5173,可用环境变量 `PORT` 覆盖)

首次启动自动建库 `data/hub.db` 并写入种子数据;删除 `data/hub.db` 可重置。

## 技术栈(零外部依赖)

- 后端:`node:sqlite`(Node 24 内置)+ 原生 `http`,提供 REST API
- 前端:原生 HTML/CSS/JS(SPA,hash 路由),无构建步骤
- 数据库:SQLite 单文件 `data/hub.db`

## 四大板块(主页一级目录)

| 板块 | 颜色 | 核心表 |
|---|---|---|
| 大模型采购 | 紫 | `model_quotes`(模型报价) |
| 服务器采购 | 蓝 | `server_quotes`(服务器报价渠道) |
| 供应商资源库 | 青 | `suppliers`(供应商台账) |
| 市场前沿信息 | 橙 | `market_intel`(市场动态) |

## 目录结构

```
purchase-hub/
├─ server.js              # 入口:HTTP + SQLite + 静态服务
├─ db/
│  ├─ schema.sql          # 建表 SQL(信息架构定义)
│  └─ seed.js             # 种子数据(真实业务字段示例)
├─ public/                # 前端
│  ├─ index.html          # 框架页(骨架)
│  ├─ css/app.css         # 设计规范变量 + 组件样式
│  ├─ js/app.js           # 路由 + 页面渲染
│  └─ js/api.js           # fetch API 封装
└─ data/                  # SQLite 数据文件(运行时生成)
```

## API 一览

- `GET /api/bootstrap` — 返回首页四板块统计 + 全部表数据
- `GET|POST|PUT|DELETE /api/<table>[/:id]` — 通用 CRUD(表:model_quotes / server_quotes / suppliers / market_intel)

## 设计令牌(等待同事视觉稿接入后替换)

在 `public/css/app.css` 顶部 `:root` 统一维护,后续整合同事视觉时只需改变量。
