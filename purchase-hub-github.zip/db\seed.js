// 种子数据 —— 基于 2026/9 先锋中心真实业务文档提炼
// 供首次启动建库时写入,便于同事理解字段含义与数据形态。

const modelQuotes = [
  // 字段:model_name, vendor, channel_type, input_price, output_price, cache_hit_price, cache_miss_price, price_factor, save_pct, tpm, quote_date, conditions, status, owner
  { model_name:'DeepSeek-V4-Flash-0731', vendor:'DeepSeek 官方', channel_type:'官方', input_price:0.3455, output_price:5.8125, cache_hit_price:0.05, cache_miss_price:1.5, price_factor:1.0, save_pct:0, tpm:'120万', quote_date:'2026-08-17', conditions:'官方基准锚点(单次请求成本 0.0144182 元)', status:'官方基准', owner:'安琪' },
  { model_name:'DeepSeek-V4-Flash-0731', vendor:'腾讯云', channel_type:'云厂商', input_price:0.2073, output_price:3.4875, cache_hit_price:null, cache_miss_price:null, price_factor:0.6, save_pct:40, tpm:'5000(随消耗调升)', quote_date:'2026-09-03', conditions:'投资 DS 原厂 100 亿;Flash 首选', status:'首选', owner:'安琪' },
  { model_name:'DeepSeek-V4-Flash-0731', vendor:'火山引擎', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:0.62, save_pct:38, tpm:'-', quote_date:'2026-09-03', conditions:'次选,可作议价筹码', status:'候选', owner:'安琪' },
  { model_name:'DeepSeek-V4-Flash-0731', vendor:'京东云', channel_type:'云厂商', input_price:0.2504, output_price:3.1969, cache_hit_price:null, cache_miss_price:null, price_factor:0.7, save_pct:30, tpm:'可按需免费调整', quote_date:'2026-09-03', conditions:'一年起签,合同待确认', status:'候选', owner:'安琪' },
  { model_name:'DeepSeek-V4-Flash-0731', vendor:'阿里云(账号2)', channel_type:'云厂商', input_price:0.3187, output_price:4.0688, cache_hit_price:null, cache_miss_price:null, price_factor:0.89, save_pct:11, tpm:'1000(随消耗调升)', quote_date:'2026-09-03', conditions:'保底年框消耗金额未定', status:'已报价', owner:'安琪' },
  { model_name:'DeepSeek-V4-Flash-0731', vendor:'阿里云(账号1)', channel_type:'云厂商', input_price:0.3827, output_price:4.3594, cache_hit_price:null, cache_miss_price:null, price_factor:1.05, save_pct:-5, tpm:'1000(随消耗调升)', quote_date:'2026-09-03', conditions:'保底年框消耗 160 万;缓存命中价 3 倍拖累', status:'已报价', owner:'安琪' },
  { model_name:'DeepSeek-V4-Flash-0731', vendor:'华为云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:3.91, save_pct:-291, tpm:'-', quote_date:'2026-09-03', conditions:'暂无折扣', status:'已报价', owner:'安琪' },
  { model_name:'DeepSeek-V4-Pro-0813', vendor:'DeepSeek 官方', channel_type:'官方', input_price:0.71875, output_price:5.8125, cache_hit_price:0.15, cache_miss_price:4.5, price_factor:1.0, save_pct:0, tpm:'120万', quote_date:'2026-08-17', conditions:'官方基准', status:'官方基准', owner:'安琪' },
  { model_name:'DeepSeek-V4-Pro-0813', vendor:'电信天翼云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:15, tpm:'可免费调整', quote_date:'2026-09-04', conditions:'85 折;闲忙时与官网同步', status:'已报价', owner:'安琪' },
  { model_name:'千问 3.7 Plus', vendor:'京东云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:null, tpm:'-', quote_date:'2026-09-04', conditions:'有优势价,重点意向', status:'谈判中', owner:'黎雨婷' },
  { model_name:'Kimi K3', vendor:'京东云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:null, tpm:'-', quote_date:'2026-09-04', conditions:'有优势价,重点意向', status:'谈判中', owner:'黎雨婷' },
  { model_name:'GLM 5.3 / 5.3 Flash', vendor:'京东云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:null, tpm:'-', quote_date:'2026-09-04', conditions:'5.3 与 Flash 同价;官方限时 5 折仅 C 端,代理 B 端无', status:'已报价', owner:'黎雨婷' },
  { model_name:'GLM 5.3', vendor:'移动云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:48, tpm:'可自行调整', quote_date:'2026-09-04', conditions:'自营部署 5.2 折;月中上线', status:'已报价', owner:'黎雨婷' },
  { model_name:'豆包 Seed 2.1 Pro(0628)', vendor:'京东云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:40, tpm:'-', quote_date:'2026-09-04', conditions:'约六折;0428/0628 版本价待确认', status:'已报价', owner:'黎雨婷' },
  { model_name:'千问 3.7 Plus', vendor:'电信天翼云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:25, tpm:'可免费调整', quote_date:'2026-09-04', conditions:'75 折', status:'已报价', owner:'黎雨婷' },
  { model_name:'千问 3.8 Flash', vendor:'电信天翼云', channel_type:'云厂商', input_price:null, output_price:null, cache_hit_price:null, cache_miss_price:null, price_factor:null, save_pct:5, tpm:'-', quote_date:'2026-09-04', conditions:'95 折,折扣给不高', status:'已报价', owner:'黎雨婷' },
];

const serverQuotes = [
  // 字段:chip_model, server_model, channel_type, channel_name, price_type, unit_price, deposit, delivery, stock, quote_date, config_note, risk_level, status, owner
  { chip_model:'H200', server_model:'超威 SYS-421GE-TNRT Switch 版', channel_type:'中介', channel_name:'天枢云', price_type:'现货', unit_price:530, deposit:'-', delivery:'期货 6-8 周到货', stock:'-', quote_date:'2026-09-03', config_note:'期货 317 万', risk_level:'待评估', status:'寻源中', owner:'安琪' },
  { chip_model:'H200', server_model:'联想问天 WA5480 G3', channel_type:'企业直采', channel_name:'中电数据产业集团', price_type:'现货', unit_price:510, deposit:'-', delivery:'-', stock:'现货 20 台', quote_date:'2026-09-03', config_note:'企业直采,可信度较高', risk_level:'低', status:'候选', owner:'安琪' },
  { chip_model:'H200', server_model:'超威', channel_type:'企业', channel_name:'香港数字资产研究院', price_type:'现货', unit_price:430, deposit:'30%', delivery:'-', stock:'-', quote_date:'2026-09-03', config_note:'-', risk_level:'中', status:'寻源中', owner:'安琪' },
  { chip_model:'H200', server_model:'超微 H200 高性能服务器', channel_type:'中介', channel_name:'四川锐速科技', price_type:'现货', unit_price:525, deposit:'45%', delivery:'一个月内交付', stock:'-', quote_date:'2026-09-03', config_note:'-', risk_level:'中', status:'寻源中', owner:'安琪' },
  { chip_model:'H200', server_model:'同泰怡 8 卡 H200 PCIE 整机', channel_type:'中介', channel_name:'四川锐速科技', price_type:'现货', unit_price:525, deposit:'30%', delivery:'-', stock:'现货 5 台(2 台已到成都)', quote_date:'2026-09-03', config_note:'-', risk_level:'中', status:'寻源中', owner:'安琪' },
  { chip_model:'H200', server_model:'超威 H200(未透露)', channel_type:'中介', channel_name:'未透露', price_type:'期货', unit_price:460, deposit:'-', delivery:'6-12 周', stock:'512 台', quote_date:'2026-09-03', config_note:'-', risk_level:'中', status:'寻源中', owner:'安琪' },
  { chip_model:'H200', server_model:'无型号', channel_type:'国内组装厂', channel_name:'未透露', price_type:'现货', unit_price:420, deposit:'-', delivery:'-', stock:'-', quote_date:'2026-09-03', config_note:'注册资金 200w 主体不强;可派人盯生产', risk_level:'高', status:'已排除', owner:'安琪' },
  { chip_model:'H200', server_model:'无型号', channel_type:'中介', channel_name:'天翼云', price_type:'现货', unit_price:550, deposit:'定金 60 万', delivery:'-', stock:'现货 6 台', quote_date:'2026-09-04', config_note:'签合同先付 60 万定金看货,看完付全款再压测', risk_level:'高', status:'已排除', owner:'安琪' },
  { chip_model:'H200', server_model:'LCWT R9480(联创万通)', channel_type:'中介', channel_name:'杭州袭格玛科技', price_type:'现货', unit_price:545, deposit:'-', delivery:'-', stock:'-', quote_date:'2026-09-04', config_note:'-', risk_level:'待评估', status:'寻源中', owner:'安琪' },
  { chip_model:'H200', server_model:'华硕 H200', channel_type:'企业', channel_name:'未透露', price_type:'现货', unit_price:400, deposit:'加价 1w 渠道费', delivery:'-', stock:'-', quote_date:'2026-09-05', config_note:'-', risk_level:'待评估', status:'寻源中', owner:'安琪' },
  { chip_model:'B300', server_model:'DELL B300-2.3T 液冷版', channel_type:'中介', channel_name:'建润股份', price_type:'现货', unit_price:1550, deposit:'-', delivery:'-', stock:'-', quote_date:'2026-09-03', config_note:'需我方提供营业执照和验资后继续谈', risk_level:'中', status:'寻源中', owner:'安琪' },
  { chip_model:'B300', server_model:'超微 B300 3T 满配', channel_type:'中介', channel_name:'-', price_type:'-', unit_price:null, deposit:'-', delivery:'-', stock:'-', quote_date:'2026-09-03', config_note:'B300 租赁渠道较少,持续沟通中', risk_level:'待评估', status:'寻源中', owner:'安琪' },
];

const suppliers = [
  { name:'腾讯云', type:'云厂商', category:'大模型', contact:'-', contact_info:'-', reg_capital:'-', founded:'-', background_check:'已通过', rating:5, main_business:'云服务 + 大模型 API(投资 DS 原厂 100 亿)', risk_note:'Flash 价格系数 0.6 最低', status:'已合作', owner:'安琪' },
  { name:'阿里云', type:'云厂商', category:'大模型', contact:'-', contact_info:'-', reg_capital:'-', founded:'-', background_check:'已通过', rating:4, main_business:'云服务 + 大模型 API(通义千问)', risk_note:'两账号报价差异大,缓存命中价偏高', status:'接触中', owner:'安琪' },
  { name:'京东云', type:'云厂商', category:'大模型', contact:'SA 赵阳', contact_info:'飞书', reg_capital:'-', founded:'-', background_check:'已通过', rating:4, main_business:'云服务 + 大模型 API + 机房托管', risk_note:'50 万以下坎级报价;合同一年起签', status:'接触中', owner:'黎雨婷' },
  { name:'华为云', type:'云厂商', category:'大模型', contact:'-', contact_info:'-', reg_capital:'-', founded:'-', background_check:'已通过', rating:2, main_business:'云服务 + 大模型 API', risk_note:'价格系数 3.91,暂无折扣', status:'接触中', owner:'安琪' },
  { name:'中国电信(广州)', type:'云厂商', category:'大模型', contact:'刘鸿臻/郭志/李志伟', contact_info:'-', reg_capital:'-', founded:'-', background_check:'已通过', rating:4, main_business:'IDC 托管 + BGP 线路 + 大模型 token', risk_note:'BGP 有友商审计风险;高密机房资源紧张', status:'接触中', owner:'黎雨婷' },
  { name:'中国移动(广州)', type:'托管商', category:'托管', contact:'移动团队', contact_info:'-', reg_capital:'-', founded:'-', background_check:'已通过', rating:4, main_business:'IDC 托管 + BGP + 大模型 token', risk_note:'GLM 5.3 五二折;资源包按抵扣系数', status:'接触中', owner:'黎雨婷' },
  { name:'四川锐速科技', type:'中介', category:'服务器', contact:'-', contact_info:'-', reg_capital:'-', founded:'-', background_check:'存疑', rating:2, main_business:'H200 服务器现货/期货', risk_note:'中介,订金 30-45%,需背调', status:'待评估', owner:'安琪' },
  { name:'中电数据产业集团', type:'企业直采', category:'服务器', contact:'-', contact_info:'-', reg_capital:'-', founded:'-', background_check:'背调中', rating:4, main_business:'联想问天 H200 企业直采', risk_note:'现货 20 台,可信度较高', status:'接触中', owner:'安琪' },
  { name:'建润股份', type:'中介', category:'服务器', contact:'-', contact_info:'-', reg_capital:'-', founded:'-', background_check:'未背调', rating:2, main_business:'DELL B300 液冷版', risk_note:'需验资;中介', status:'待评估', owner:'安琪' },
];

const marketIntel = [
  { title:'昇腾 950 系列产品路线', category:'芯片路标', source:'华为线下沟通', url:'', summary:'950 PR(推理)已售,950 DT(训练)9 月发布/10 月上市;960 明年 Q4,970 2028 Q4;950 对标英伟达 B300,集群有优势', publish_date:'2026-09-03', tags:'华为,昇腾,950,国产芯片', importance:'高', status:'待阅', owner:'安琪' },
  { title:'GPU 服务器现货采购风险预警', category:'调研报告', source:'内部', url:'', summary:'风险规避六步:配置单→背调→合同→验货→压测→交易(现场付款自提)', publish_date:'2026-09-04', tags:'风险,采购,验货,压测', importance:'高', status:'已阅', owner:'安琪' },
  { title:'DeepSeek 官方基准价(2026-08-17 新价)', category:'模型动态', source:'内部测算', url:'', summary:'官方 Flash 单次请求成本 0.0144182 元 = 价格系数 1.0;全厂商统一口径折算', publish_date:'2026-09-03', tags:'DeepSeek,基准价,价格系数', importance:'高', status:'已阅', owner:'安琪' },
  { title:'海外大模型中转站报价模式', category:'模型动态', source:'建联', url:'', summary:'官转最可控 > 原厂转半可控 > 号池不可控(封号风险);GLM 官转约 7 折,七牛云 6.5 折更优', publish_date:'2026-09-05', tags:'中转站,GLM,ChatGPT,报价', importance:'中', status:'待阅', owner:'黎雨婷' },
  { title:'国产海光处理器入英伟达库档', category:'芯片路标', source:'采购早会', url:'', summary:'海光处理器已入英伟达库档,可布 K2/K3,需纳入服务器性能对比', publish_date:'2026-09-04', tags:'海光,国产处理器,英伟达', importance:'中', status:'待阅', owner:'黎雨婷' },
];

module.exports = { modelQuotes, serverQuotes, suppliers, marketIntel };
