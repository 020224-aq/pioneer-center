// 先锋中心 · 采购资源中枢 —— 前端(深色太空主题版)
// 交互:粒子背景 / 开屏动画 / 玻璃卡片 tilt / 主题切换
// 数据:真实 MySQL pc_ 表(经 /api/bootstrap 聚合)

let DATA = null;

// ============ 四大板块配置 ============
const MODULES = {
  model:    { key: 'model',    title: '大模型采购',  en: 'LLM Procurement',   theme: 'c1', icon: 'spark' },
  server:   { key: 'server',   title: '服务器采购',  en: 'Server Procurement', theme: 'c2', icon: 'server' },
  supplier: { key: 'supplier', title: '供应商库',    en: 'Vendor Library',     theme: 'c3', icon: 'vendor' },
  intel:    { key: 'intel',    title: '市场前沿信息', en: 'Market Insight',    theme: 'c4', icon: 'insight' },
};

function iconSvg(name) {
  const s = 'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
  const map = {
    spark: `<svg class="h-5 w-5" style="color:var(--accent)" viewBox="0 0 24 24" ${s}><path d="M12 3 14.5 9.5 21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3z"/></svg>`,
    server: `<svg class="h-5 w-5" style="color:var(--accent)" viewBox="0 0 24 24" ${s}><rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/></svg>`,
    vendor: `<svg class="h-5 w-5" style="color:var(--accent)" viewBox="0 0 24 24" ${s}><path d="M3 21V8l9-5 9 5v13"/><path d="M9 21V12h6v9"/></svg>`,
    insight: `<svg class="h-5 w-5" style="color:var(--accent)" viewBox="0 0 24 24" ${s}><path d="M2 12a10 10 0 0 1 20 0"/><circle cx="12" cy="12" r="2"/><path d="M12 14v7"/></svg>`,
  };
  return map[name] || '';
}

// ============ 工具 ============
function esc(s) { if (s === null || s === undefined) return ''; return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function badge(text, tone = 'gray') { if (!text) return '<span class="badge badge-gray">—</span>'; return `<span class="badge badge-${tone}">${esc(text)}</span>`; }
function statusTone(s) {
  if (!s) return 'gray';
  if (/已合作|完成|已通过|green|正常/.test(s)) return 'green';
  if (/首选|谈判|候选|接触|进行|排期|核验|warn|待/.test(s)) return 'orange';
  if (/排除|放弃|风险|red|存疑|加急/.test(s)) return 'red';
  return 'gray';
}
function catTone(c) { if (c === '芯片路标') return 'purple'; if (c === '模型动态') return 'blue'; if (c === '调研报告') return 'teal'; if (c === '行业动态') return 'orange'; return 'gray'; }
function lvTone(lv) { if (lv === 'green' || lv === 'low') return 'green'; if (lv === 'warn' || lv === 'medium') return 'orange'; if (lv === 'red' || lv === 'high') return 'red'; return 'gray'; }

function renderTable(columns, rows) {
  if (!rows || !rows.length) return `<div style="text-align:center;color:var(--text-3);padding:40px">暂无数据</div>`;
  const head = columns.map(c => `<th>${c.label}</th>`).join('');
  const body = rows.map(r => `<tr>${columns.map(c => `<td>${c.render ? c.render(r) : esc(r[c.key])}</td>`).join('')}</tr>`).join('');
  return `<div class="table-wrap"><table class="data"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}

// ============ 侧边栏渲染 ============
function renderNav(active) {
  const nav = document.getElementById('primaryNav');
  const items = [
    { key: 'home', title: '工作台', icon: 'spark' },
    ...Object.values(MODULES),
  ];
  nav.innerHTML = items.map(m => {
    const cnt = m.key === 'home' ? null : statCount(m.key);
    return `
    <div class="sidebar-item ${active === m.key ? 'active' : ''}" data-key="${m.key}">
      <span class="glow-bar"></span>
      <span class="icon-wrap">${iconSvg(m.icon)}</span>
      <span class="nav-label" style="flex:1">${m.title}</span>
      ${cnt !== null ? `<span class="nav-badge chip" style="padding:1px 8px">${cnt}</span>` : ''}
    </div>`;
  }).join('');
  nav.querySelectorAll('.sidebar-item').forEach(el => {
    el.addEventListener('click', () => { location.hash = '#/' + el.dataset.key; });
  });
}

function statCount(key) {
  if (!DATA || !DATA.stats) return 0;
  const s = DATA.stats;
  return { model: s.model_items, server: s.server_items, supplier: s.channel_items, intel: s.intel_items }[key] || 0;
}

// ============ 首页(工作台) ============
function renderHome() {
  document.body.removeAttribute('data-theme');
  const cards = Object.values(MODULES).map(m => ({ ...m, count: statCount(m.key) }));
  const feed = (DATA.feed || []).slice(0, 5);

  const moduleHtml = cards.map(m => `
    <button class="glass flow p-5 text-left group" data-jump="${m.key}" data-theme="${m.theme}" data-tilt data-tilt-strength="6" style="width:100%">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
        <div class="module-icon" style="width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg, color-mix(in srgb, var(--accent) 18%, transparent), transparent);border:1px solid color-mix(in srgb, var(--accent) 35%, transparent);box-shadow:0 0 18px -4px color-mix(in srgb, var(--accent) 50%, transparent)">
          ${iconSvg(m.icon)}
        </div>
        <span style="font-size:10.5px;letter-spacing:.25em;color:#64748b">${m.en.split(' ')[0]}</span>
      </div>
      <div style="font-size:15px;font-weight:600;color:#fff">${m.title}</div>
      <div style="margin-top:4px;font-size:12px;color:#94a3b8;line-height:1.6">${moduleDesc(m.key)}</div>
      <div style="margin-top:20px;display:flex;align-items:center;justify-content:space-between">
        <span class="chip"><span class="pip"></span>${m.count} 条记录</span>
        <span style="font-size:12px;color:#cbd5e1" class="group-hover:text-[var(--accent)]">进入 →
        </span>
      </div>
    </button>`).join('');

  const statHtml = [
    { l: '大模型采购', v: statCount('model') },
    { l: '服务器采购', v: statCount('server') },
    { l: '供应商', v: statCount('supplier') },
    { l: '市场情报', v: statCount('intel') },
  ].map(s => `
    <div class="glass p-5" data-tilt data-tilt-strength="4">
      <div style="font-size:11.5px;letter-spacing:.05em;color:#94a3b8">${s.l}</div>
      <div style="margin-top:8px;font-size:28px;font-weight:700;color:#fff">${s.v}</div>
    </div>`).join('');

  const feedHtml = feed.map(f => `
    <div class="row-item">
      <span style="width:8px;height:8px;border-radius:50%;background:var(--accent);box-shadow:0 0 8px var(--accent)"></span>
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.who || '系统')}</div>
        <div style="font-size:11px;color:#64748b">${esc(f.time || '')}</div>
      </div>
      <span class="chip"><span class="pip"></span>${esc(f.type || '动态')}</span>
    </div>`).join('');

  return `
  <section class="reveal-up">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:24px">
      <div>
        <p style="font-size:12px;color:#94a3b8">${todayStr()}</p>
        <h1 style="margin-top:8px;font-size:34px;font-weight:700;line-height:1.2">早安,<span class="text-grad">安琪</span> 👋</h1>
        <p style="margin-top:8px;font-size:14px;color:#94a3b8;max-width:640px">欢迎回到 <span style="color:#fff">先锋中心</span>。点击左侧一级菜单,进入大模型采购 / 服务器采购 / 供应商库 / 市场前沿信息。</p>
      </div>
      <div style="display:flex;align-items:center;gap:10px">
        <button class="btn-ghost">导出报表</button>
        <button class="btn-primary">+ 新建采购任务</button>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:18px" class="stagger">${moduleHtml}</div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-top:24px" class="stagger">${statHtml}</div>

    <div style="margin-top:24px" class="stagger">
      <div class="glass p-5" data-tilt data-tilt-strength="3">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
          <div style="font-size:14px;font-weight:600">决策动态</div>
          <span class="chip"><span class="pip"></span>${(DATA.feed || []).length} 条</span>
        </div>
        <div>${feedHtml || '<div style="color:var(--text-3);text-align:center;padding:24px">暂无动态</div>'}</div>
      </div>
    </div>
  </section>`;
}

function todayStr() {
  const d = new Date();
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const mons = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${days[d.getDay()]}, ${mons[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

function moduleDesc(key) {
  return {
    model: '统一管理大模型选型、报价对比与成本优化',
    server: '算力服务器寻源、报价对比与部署决策',
    supplier: '渠道台账、背调状态与供应商评级',
    intel: '芯片路标、行业动态与调研报告',
  }[key] || '';
}

// ============ 大模型采购(iframe 完整原型) ============
// 完全依照同事的设计原型(8 系列 24 模型 + 三级详情 + 日志轴 + 系数测算)
// 视觉已翻译为深色太空玻璃,交互与内容 100% 与原型一致
function renderModel() {
  return `<section class="reveal-up" style="height:calc(100vh - 96px);display:flex;flex-direction:column">
    <iframe
      src="/llm/index.html"
      style="flex:1;width:100%;border:0;border-radius:16px;background:#04060f"
      title="大模型采购"
      loading="eager"></iframe>
  </section>`;
}

// ============ 服务器采购(iframe 完整原型 ServerHub) ============
// 完全依照同事的 ServerHub 设计原型(购买/租赁双路径 + 本地/托管部署 + 背调/验货流程勾选)
// 视觉已翻译为深色太空玻璃(与中枢统一),内容与交互 100% 与原型一致
function renderServer() {
  return `<section class="reveal-up" style="height:calc(100vh - 96px);display:flex;flex-direction:column">
    <iframe
      src="/server/index.html"
      style="flex:1;width:100%;border:0;border-radius:16px;background:#04060f"
      title="服务器采购"
      loading="eager"></iframe>
  </section>`;
}

// ============ 供应商库 ============
function renderSupplier() {
  return `<section class="reveal-up" style="height:calc(100vh - 96px);display:flex;flex-direction:column">
    <iframe
      src="/supplier/index.html"
      style="flex:1;width:100%;border:0;border-radius:16px;background:#f5f5f7"
      title="供应商资源库"
      loading="eager"></iframe>
  </section>`;
}

// ============ 市场前沿信息(iframe 完整原型 情报中枢) ============
// 完全依照同事的市场情报中枢原型(LLM 前沿动态 / AI 全产业链 / 国际信息直连 三 Tab)
// 保留原始深色 Bloomberg 终端风格与悬停流动感,内容与交互 100% 与原型一致
function renderIntel() {
  return `<section class="reveal-up" style="height:calc(100vh - 96px);display:flex;flex-direction:column">
    <iframe
      src="/market/index.html"
      style="flex:1;width:100%;border:0;border-radius:16px;background:#0a1628"
      title="市场前沿信息"
      loading="eager"></iframe>
  </section>`;
}

function bindIntelFilter() {
  const filter = document.getElementById('intelFilter');
  if (!filter || filter.dataset.bound === '1') return;
  filter.dataset.bound = '1';
  const rows = DATA.intel || [];
  filter.addEventListener('click', e => {
    const btn = e.target.closest('[data-cat]');
    if (!btn) return;
    filter.querySelectorAll('[data-cat]').forEach(b => b.classList.remove('filter-on'));
    btn.classList.add('filter-on');
    const cat = btn.dataset.cat;
    const list = document.getElementById('intelList');
    const filtered = cat === '全部' ? rows : rows.filter(r => r.cat === cat);
    list.innerHTML = filtered.map(r => {
      const impCls = r.imp === '高' ? 'badge-red' : r.imp === '中' ? 'badge-orange' : 'badge-gray';
      return `<div class="glass p-5" data-tilt data-tilt-strength="3" style="display:flex;gap:14px;align-items:flex-start">
        <div style="flex:0 0 44px;height:44px;border-radius:12px;display:grid;place-items:center;font-size:18px;background:linear-gradient(135deg,rgba(165,119,255,.30),rgba(29,12,112,.25));border:1px solid rgba(255,255,255,.14)">◆</div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <span class="badge ${catTone(r.cat)}">${esc(r.cat || '资讯')}</span>
            <span class="badge ${impCls}">${esc(r.imp || '中')}</span>
            <span style="font-size:11px;color:#64748b;margin-left:auto">${esc(r.date || '')} · ${esc(r.src || '')}</span>
          </div>
          <div style="font-weight:700;color:#fff;font-size:15px;margin-top:8px">${esc(r.title)}</div>
          ${r.summary ? `<div style="font-size:12.5px;color:#94a3b8;line-height:1.6;margin-top:6px">${esc(r.summary)}</div>` : ''}
          ${r.tags ? `<div style="margin-top:8px">${String(r.tags).split(',').map(t => `<span class="chip" style="margin:2px">${esc(t.trim())}</span>`).join('')}</div>` : ''}
        </div>
      </div>`;
    }).join('') || '<div class="empty">该分类暂无情报</div>';
    bindTilt();
  });
}

function lvBadge(lv) {
  if (!lv) return '';
  const map = { low: ['低', 'green'], medium: ['中', 'orange'], high: ['高', 'red'] };
  const m = map[lv];
  return m ? badge('风险 ' + m[0], m[1]) : '';
}

// ============ 路由 ============
const ROUTES = { home: renderHome, model: renderModel, server: renderServer, supplier: renderSupplier, intel: renderIntel };

function setContent(html) {
  const area = document.getElementById('mainArea');
  area.innerHTML = html;
  bindTilt();
  bindIntelFilter();
}

function router() {
  const hash = location.hash.replace(/^#\/?/, '');
  const key = ROUTES[hash] ? hash : 'home';
  renderNav(key);
  const m = MODULES[key];
  if (m) document.body.setAttribute('data-theme', m.theme);
  else document.body.removeAttribute('data-theme');
  setContent(ROUTES[key]());
}

// ============ 玻璃卡片 tilt 交互 ============
function bindTilt() {
  document.querySelectorAll('[data-tilt]').forEach(el => {
    if (el.dataset.tiltBound === '1') return;
    el.dataset.tiltBound = '1';
    const strength = parseFloat(el.dataset.tiltStrength || '5');
    el.addEventListener('pointermove', e => {
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      el.style.setProperty('--mx', (px * 100).toFixed(1) + '%');
      el.style.setProperty('--my', (py * 100).toFixed(1) + '%');
      el.style.setProperty('--rx', ((0.5 - py) * strength).toFixed(2) + 'deg');
      el.style.setProperty('--ry', ((px - 0.5) * strength).toFixed(2) + 'deg');
    });
    el.addEventListener('pointerleave', () => {
      el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg');
      el.style.setProperty('--mx', '50%'); el.style.setProperty('--my', '50%');
    });
  });
}

// ============ 粒子背景 ============
function initParticles(canvas, opts = {}) {
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  let w, h, particles = [];
  const cfg = Object.assign({ density: 0.00009, speed: 0.25, connectDist: 120, glow: 12 }, opts);
  function resize() {
    const rect = canvas.getBoundingClientRect();
    w = rect.width; h = rect.height;
    canvas.width = w * dpr; canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const count = Math.max(40, Math.floor(w * h * cfg.density));
    particles = Array.from({ length: count }, () => spawn());
  }
  function spawn() {
    return { x: Math.random() * w, y: Math.random() * h,
      vx: (Math.random() - 0.5) * cfg.speed, vy: (Math.random() - 0.5) * cfg.speed,
      r: Math.random() * 1.6 + 0.4,
      hue: ['105,217,255','165,119,255','92,255,255','43,62,217'][Math.floor(Math.random() * 4)] };
  }
  function tick() {
    ctx.clearRect(0, 0, w, h);
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x, dy = particles[i].y - particles[j].y;
        const d2 = dx * dx + dy * dy;
        if (d2 < cfg.connectDist * cfg.connectDist) {
          const a = 1 - d2 / (cfg.connectDist * cfg.connectDist);
          ctx.strokeStyle = `rgba(${particles[i].hue}, ${a * 0.18})`;
          ctx.lineWidth = 0.7;
          ctx.beginPath(); ctx.moveTo(particles[i].x, particles[i].y); ctx.lineTo(particles[j].x, particles[j].y); ctx.stroke();
        }
      }
    }
    for (const p of particles) {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > w) p.vx *= -1;
      if (p.y < 0 || p.y > h) p.vy *= -1;
      ctx.beginPath();
      ctx.fillStyle = `rgba(${p.hue}, .8)`;
      ctx.shadowBlur = cfg.glow; ctx.shadowColor = `rgba(${p.hue}, .7)`;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.shadowBlur = 0;
    requestAnimationFrame(tick);
  }
  window.addEventListener('resize', resize);
  resize(); tick();
}

// ============ 事件委托(卡片跳转) ============
document.addEventListener('click', e => {
  const jump = e.target.closest('[data-jump]');
  if (jump) { location.hash = '#/' + jump.dataset.jump; }
});

// ============ 启动 ============
async function init() {
  try { DATA = await API.get('bootstrap'); }
  catch (e) {
    document.getElementById('mainArea').innerHTML =
      `<div style="color:var(--text-3);padding:60px;text-align:center">无法连接后端:${esc(e.message)}<br>请运行 <code>node server.js</code></div>`;
  }
  window.addEventListener('hashchange', router);

  // splash 粒子
  const splashCanvas = document.getElementById('splashCanvas');
  if (splashCanvas) initParticles(splashCanvas, { density: 0.00012, speed: 0.4 });

  // 工作台粒子
  setTimeout(() => {
    const bg = document.getElementById('bgCanvas');
    if (bg) initParticles(bg, { density: 0.00007, speed: 0.2 });
  }, 2200);

  // 2.2s 结束 splash
  setTimeout(() => {
    const splash = document.getElementById('splash');
    const app = document.getElementById('app');
    if (splash) {
      splash.classList.add('splash-leaving');
      app.classList.remove('hidden');
      app.classList.add('app-in');
      setTimeout(() => splash.remove(), 600);
      router();
    }
  }, 2200);
}

// ============ 全局搜索 ============
function buildSearchIndex() {
  const idx = [];
  // 服务器报价(serverBoard)
  for (const b of DATA.serverBoard || []) {
    for (const q of b.quotes || []) {
      idx.push({
        kind: 'server', icon: '服', title: `${q.asset_name || q.asset || ''} · ${q.channel || ''}`,
        sub: `${q.type || ''} ${q.price || ''}${q.unit || ''} ${q.quote_date || ''}`,
        kw: `${q.asset_name || ''} ${q.asset || ''} ${q.channel || ''} ${q.server_model || ''} ${q.chip_model || ''}`.toLowerCase(),
        hash: '#/server',
      });
    }
  }
  // 供应商
  for (const c of DATA.channels || []) {
    idx.push({
      kind: 'supplier', icon: '供', title: c.name || '',
      sub: `${c.kind || ''} · ${c.status || ''} · 报价${c.deal || 0}条`,
      kw: `${c.name || ''} ${c.kind || ''} ${c.type || ''} ${c.main_business || ''}`.toLowerCase(),
      hash: '#/supplier',
    });
  }
  // 市场情报
  for (const it of DATA.intel || []) {
    idx.push({
      kind: 'intel', icon: '讯', title: it.title || '',
      sub: `${it.cat || ''} · ${it.src || ''} · ${it.date || ''}`,
      kw: `${it.title || ''} ${it.cat || ''} ${it.src || ''} ${it.summary || ''} ${it.tags || ''}`.toLowerCase(),
      hash: '#/intel',
    });
  }
  // 任务 / 决策动态
  for (const t of DATA.tasks || []) {
    idx.push({
      kind: 'task', icon: '任', title: t.name || t.title || '',
      sub: `${t.owner || ''} · ${t.date || ''}`,
      kw: `${t.name || ''} ${t.title || ''} ${t.owner || ''}`.toLowerCase(),
      hash: '#/home',
    });
  }
  return idx;
}

function hl(text, kw) {
  if (!kw) return esc(text);
  const i = String(text).toLowerCase().indexOf(kw.toLowerCase());
  if (i < 0) return esc(text);
  const s = String(text);
  return esc(s.slice(0, i)) + '<span class="sp-highlight">' + esc(s.slice(i, i + kw.length)) + '</span>' + esc(s.slice(i + kw.length));
}

function renderSearch(q) {
  const panel = document.getElementById('searchPanel');
  if (!panel) return;
  if (!q || !q.trim()) { panel.classList.add('hidden'); panel.innerHTML = ''; return; }
  const kw = q.trim();
  const idx = buildSearchIndex();
  const hits = idx.filter(x => x.kw.includes(kw.toLowerCase())).slice(0, 30);
  if (!hits.length) {
    panel.innerHTML = '<div class="sp-empty">未找到匹配「' + esc(kw) + '」的结果</div>';
    panel.classList.remove('hidden');
    return;
  }
  const groups = { server: '服务器报价', supplier: '供应商', intel: '市场情报', task: '任务' };
  const byKind = {};
  for (const h of hits) { (byKind[h.kind] = byKind[h.kind] || []).push(h); }
  let html = '';
  for (const k of Object.keys(groups)) {
    if (!byKind[k]) continue;
    html += '<div class="sp-group">' + groups[k] + '</div>';
    for (const h of byKind[k]) {
      html += `<div class="sp-item" data-searchhash="${h.hash}">
        <span class="sp-ico">${h.icon}</span>
        <div style="flex:1;min-width:0"><div class="sp-title">${hl(h.title, kw)}</div><div class="sp-sub">${esc(h.sub)}</div></div>
      </div>`;
    }
  }
  panel.innerHTML = html;
  panel.classList.remove('hidden');
}

function initSearch() {
  const input = document.getElementById('searchInput');
  const panel = document.getElementById('searchPanel');
  if (!input) return;
  input.addEventListener('input', () => renderSearch(input.value));
  input.addEventListener('focus', () => { if (input.value) renderSearch(input.value); });
  document.addEventListener('click', e => {
    const item = e.target.closest('[data-searchhash]');
    if (item) {
      location.hash = item.dataset.searchhash;
      input.value = '';
      panel.classList.add('hidden');
      return;
    }
    if (!e.target.closest('#searchPanel') && !e.target.closest('.search-box')) {
      panel.classList.add('hidden');
    }
  });
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f') {
      e.preventDefault(); input.focus();
    }
  });
}

init();
initSearch();
