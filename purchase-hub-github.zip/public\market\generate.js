// 生成「市场前沿信息」单文件 HTML（整合 py 脚本逻辑 + 3 份 JSON + CSS）
const fs = require('fs');
const path = require('path');

const ROOT = 'C:/Users/16512/AppData/Roaming/FanDo/openclaw/workspace-agent-2/purchase-hub/public/market';

const css = fs.readFileSync(path.join(ROOT, 'style.css'), 'utf8');
const llm = JSON.parse(fs.readFileSync(path.join(ROOT, 'llm.json'), 'utf8'));
const industry = JSON.parse(fs.readFileSync(path.join(ROOT, 'industry.json'), 'utf8'));
const intl = JSON.parse(fs.readFileSync(path.join(ROOT, 'intl.json'), 'utf8'));

const llmJson = JSON.stringify(llm);
const industryJson = JSON.stringify(industry);
const intlJson = JSON.stringify(intl);

// Tab 切换样式（py 脚本里内联的，CSS 里没有）
const tabCss = `
.tab-bar{display:flex;gap:8px;background:var(--bg-card);border:1px solid var(--border);border-radius:12px;padding:6px;margin-bottom:24px;flex-wrap:wrap}
.tab-btn{padding:10px 20px;border-radius:8px;border:1px solid transparent;background:transparent;color:var(--text-secondary);font-size:13px;cursor:pointer;transition:all .2s;font-family:inherit}
.tab-btn:hover{color:var(--text-primary);background:var(--bg-hover)}
.tab-btn.active{background:var(--accent-cyan);color:var(--bg-primary);font-weight:600;border-color:var(--accent-cyan)}
.tab-content{display:none}
.tab-content.active{display:block}
`;

const js = `
// 工具函数
function escapeHtml(t){if(t==null)return'';const d=document.createElement('div');d.textContent=String(t);return d.innerHTML}
function truncate(t,maxLen){if(!t)return'';maxLen=maxLen||600;return t.length>maxLen?t.slice(0,maxLen)+'...':t}
function formatNumber(n){if(n==null)return'-';if(n>=1e9)return(n/1e9).toFixed(2)+'B';if(n>=1e6)return(n/1e6).toFixed(2)+'M';if(n>=1e3)return(n/1e3).toFixed(1)+'K';return n.toLocaleString()}

function renderLLM(data){
  const s=data.summary||{};
  const metrics=[
    {label:'监测模型总数',value:s.total_models||0,change:s.models_change,color:'cyan'},
    {label:'今日调用总量',value:formatNumber(s.total_calls_24h),change:s.calls_change,color:'green'},
    {label:'新模型/版本',value:s.new_count||0,color:'purple'},
    {label:'价格调整',value:s.price_change_count||0,color:'orange'},
    {label:'平均价格/1M',value:s.avg_price?'$'+Number(s.avg_price).toFixed(2):'-',change:s.price_change_pct,color:'yellow'}
  ];
  const insightsHtml=(data.insights||[]).map(it=>\`<div class="item-card \${it.priority||''}"><div class="item-card-header"><div class="item-card-title">\${escapeHtml(it.title)}</div><div class="item-card-meta"><span class="item-card-tag \${it.tag||'trend'}">\${(it.tag||'trend').toUpperCase()}</span></div></div><div class="item-card-summary">\${escapeHtml(it.content)}</div>\${it.action?'<div class="item-card-footer"><span style="color:var(--accent-cyan)">💡 建议：'+escapeHtml(it.action)+'</span></div>':''}</div>\`).join('');
  const hottestRows=(data.hottest||[]).map((m,idx)=>{const rc=idx===0?'gold':idx===1?'silver':idx===2?'bronze':'';return '<tr><td><span class="rank '+rc+'">#'+(idx+1)+'</span></td><td><strong>'+escapeHtml(m.name)+'</strong><br><span style="font-size:11px;color:var(--text-muted);font-family:var(--font-mono)">'+escapeHtml(m.id)+'</span></td><td>'+escapeHtml(m.provider)+'</td><td>'+formatNumber(m.calls_24h)+'</td><td>'+formatNumber(m.tokens_24h)+'</td><td><span class="price">$'+Number(m.input_price).toFixed(2)+' / $'+Number(m.output_price).toFixed(2)+'</span></td><td>'+(m.context_length>=1024?(m.context_length/1024).toFixed(0)+'K':m.context_length)+'</td></tr>'}).join('');
  const valueRows=(data.best_value||[]).map((m,idx)=>{const rc=idx===0?'gold':idx===1?'silver':idx===2?'bronze':'';return '<tr><td><span class="rank '+rc+'">#'+(idx+1)+'</span></td><td><strong>'+escapeHtml(m.name)+'</strong><br><span style="font-size:11px;color:var(--text-muted);font-family:var(--font-mono)">'+escapeHtml(m.id)+'</span></td><td>'+escapeHtml(m.provider)+'</td><td><span class="score text-cyan">'+Number(m.value_score).toFixed(1)+'</span></td><td>'+(m.benchmark_score?Number(m.benchmark_score).toFixed(0):'-')+'</td><td><span class="price">$'+Number(m.input_price).toFixed(2)+' / $'+Number(m.output_price).toFixed(2)+'</span></td><td>'+escapeHtml(m.best_for||'-')+'</td></tr>'}).join('');
  const newModelsHtml=(data.new_models||[]).map(m=>\`<div class="item-card purple"><div class="item-card-header"><div class="item-card-title">\${escapeHtml(m.name)} <span style="font-family:var(--font-mono);font-size:12px;color:var(--text-muted)">\${escapeHtml(m.id)}</span></div><div class="item-card-meta"><span class="item-card-tag new">NEW</span>\${m.hotness?'<span class="item-card-tag trend">🔥 '+formatNumber(m.hotness)+' calls</span>':''}</div></div><div class="item-card-summary">\${escapeHtml(m.description)}\${m.highlights?'<ul style="margin-top:8px;padding-left:20px">'+m.highlights.map(h=>'<li style="margin-bottom:4px">'+escapeHtml(h)+'</li>').join('')+'</ul>':''}</div><div class="item-card-footer"><div class="flex gap-12"><span>厂商: <strong>'+escapeHtml(m.provider)+'</strong></span><span>上下文: <strong>'+(m.context_length>=1024?(m.context_length/1024).toFixed(0)+'K':m.context_length)+'</strong></span><span>价格: <strong>$'+Number(m.input_price).toFixed(2)+' / $'+Number(m.output_price).toFixed(2)+'</strong> per 1M</span><span>潜力指数: <strong class="text-purple">'+(m.potential_score||'-')+'</strong></span></div>\${m.url?'<a href="'+m.url+'" target="_blank" class="item-card-link">查看 →</a>':''}</div></div>\`).join('');
  const priceRows=(data.price_changes||[]).map(c=>\`<tr><td><strong>\${escapeHtml(c.model_name)}</strong><br><span style="font-size:11px;color:var(--text-muted);font-family:var(--font-mono)">\${escapeHtml(c.model_id)}</span></td><td>\${escapeHtml(c.provider)}</td><td><span class="price">$\${Number(c.old_input).toFixed(3)} → $\${Number(c.new_input).toFixed(3)}</span><br><span class="metric-change \${c.input_change_pct>=0?'up':'down'}" style="font-size:11px">\${c.input_change_pct>=0?'↑':'↓'} \${Math.abs(c.input_change_pct).toFixed(1)}%</span></td><td><span class="price">$\${Number(c.old_output).toFixed(3)} → $\${Number(c.new_output).toFixed(3)}</span><br><span class="metric-change \${c.output_change_pct>=0?'up':'down'}" style="font-size:11px">\${c.output_change_pct>=0?'↑':'↓'} \${Math.abs(c.output_change_pct).toFixed(1)}%</span></td><td>\${escapeHtml(c.reason||'-')}</td></tr>\`).join('');
  return \`<div class="metrics-grid">\${metrics.map(m=>'<div class="metric-card '+m.color+'"><div class="metric-label">'+m.label+'</div><div class="metric-value">'+m.value+'</div>'+(m.change!=null?'<div class="metric-change '+(m.change>=0?'up':'down')+'">'+(m.change>=0?'↑':'↓')+' '+Math.abs(m.change).toFixed(1)+'%</div>':'')+'</div>').join('')}</div>
\${insightsHtml?'<h2 class="section-title">💡 今日核心洞察 <span class="badge">'+(data.insights||[]).length+'</span></h2><div class="content-grid">'+insightsHtml+'</div>':''}
<h2 class="section-title">🔥 最受市场欢迎 Top 10 <span class="badge">按 24h 调用量</span></h2><table class="model-table"><thead><tr><th>#</th><th>模型</th><th>厂商</th><th>24h 调用量</th><th>Token 消耗</th><th>价格/1M</th><th>上下文</th></tr></thead><tbody>\${hottestRows}</tbody></table>
<h2 class="section-title">💰 性价比最高 Top 10 <span class="badge">性能/价格比</span></h2><table class="model-table"><thead><tr><th>#</th><th>模型</th><th>厂商</th><th>性价比分</th><th>综合能力</th><th>价格/1M</th><th>擅长领域</th></tr></thead><tbody>\${valueRows}</tbody></table>
<h2 class="section-title">🚀 最新推出 - 极具潜力 <span class="badge">\${(data.new_models||[]).length}</span></h2><div class="content-grid">\${newModelsHtml}</div>
\${priceRows?'<h2 class="section-title">📊 今日价格异动 <span class="badge">'+(data.price_changes||[]).length+'</span></h2><table class="model-table"><thead><tr><th>模型</th><th>厂商</th><th>输入价格</th><th>输出价格</th><th>原因</th></tr></thead><tbody>'+priceRows+'</tbody></table>':''}\`;
}

function renderIndustry(data){
  const s=data.summary||{};
  const news=data.news||[];
  const metrics=[
    {label:'今日资讯总数',value:s.total||0,color:'cyan'},
    {label:'高优先级',value:s.high_priority||0,color:'red'},
    {label:'硬件/芯片',value:s.hardware_count||0,color:'purple'},
    {label:'政策动态',value:s.policy_count||0,color:'policy'},
    {label:'能源/电力',value:s.energy_count||0,color:'energy'}
  ];
  const categoryLabels={software:{icon:'💻',title:'软件开发'},hardware:{icon:'🖥️',title:'硬件开发'},chip:{icon:'🔧',title:'上游芯片'},component:{icon:'⚙️',title:'配件供应'},policy:{icon:'📜',title:'政策监管'},energy:{icon:'⚡',title:'能源电力'},investment:{icon:'💰',title:'投融资'},research:{icon:'🔬',title:'学术前沿'}};
  const grouped={};
  news.forEach(n=>{if(!grouped[n.category])grouped[n.category]=[];grouped[n.category].push(n)});
  const priorityOrder={high:0,medium:1,low:2};
  Object.keys(grouped).forEach(cat=>{grouped[cat].sort((a,b)=>(priorityOrder[a.priority]??2)-(priorityOrder[b.priority]??2))});
  const sections=Object.keys(categoryLabels).filter(k=>grouped[k]).map(cat=>{
    const items=grouped[cat];const meta=categoryLabels[cat];
    return '<h2 class="section-title">'+meta.icon+' '+meta.title+' <span class="badge">'+items.length+'</span></h2><div class="content-grid">'+items.map(n=>\`<div class="item-card \${n.priority||''}"><div class="item-card-header"><div class="item-card-title">\${escapeHtml(n.title)}</div><div class="item-card-meta"><span class="item-card-tag \${n.sub_tag||''}">\${escapeHtml(n.sub_tag||n.category).toUpperCase()}</span></div></div><div class="item-card-summary">\${escapeHtml(n.summary)}</div>\${n.details?'<div style="margin-top:8px;padding:10px;background:var(--bg-tertiary);border-radius:6px;font-size:12px;color:var(--text-muted);line-height:1.7">'+escapeHtml(n.details)+'</div>':''}<div class="item-card-footer"><div class="flex gap-12"><span>📡 '+escapeHtml(n.source)+'</span><span>🕐 '+escapeHtml(n.published||'-')+'</span>\${n.region?'<span>🌐 '+escapeHtml(n.region)+'</span>':''}</div>\${n.url?'<a href="'+n.url+'" target="_blank" class="item-card-link">查看原文 →</a>':''}</div></div>\`).join('')+'</div>';
  }).join('');
  return '<div class="metrics-grid">'+metrics.map(i=>'<div class="metric-card '+i.color+'"><div class="metric-label">'+i.label+'</div><div class="metric-value">'+i.value+'</div></div>').join('')+'</div>'+sections;
}

function renderIntl(data){
  const s=data.summary||{};
  const articles=data.articles||[];
  const metrics=[
    {label:'今日文章总数',value:s.total||0,color:'cyan'},
    {label:'The Batch',value:s.batch_count||0,color:'orange'},
    {label:'VentureBeat',value:s.vb_count||0,color:'purple'},
    {label:'其他来源',value:s.other_count||0,color:'green'}
  ];
  const articlesHtml=articles.map(a=>{
    const sourceLabel=(a.source||'').replace(/_/g,' ').toUpperCase();
    return \`<article class="article-card"><header class="article-header"><h3 class="article-title">\${escapeHtml(a.title_cn||a.title)}</h3><div class="article-meta"><span class="article-tag">\${sourceLabel}</span>\${a.category?'<span class="article-tag">'+escapeHtml(a.category)+'</span>':''}<span>\${escapeHtml(a.published||'')}</span></div></header>\${a.summary_cn?'<div class="article-section translated"><div class="article-section-label">📝 摘要译文</div><div class="article-content">'+escapeHtml(a.summary_cn)+'</div></div>':''}\${a.title_en?'<div class="article-section original"><div class="article-section-label">🇬🇧 原文标题</div><div class="article-content original">'+escapeHtml(a.title_en)+'</div></div>':''}\${a.content_en?'<div class="article-section original"><div class="article-section-label">🇬🇧 原文摘录</div><div class="article-content original">'+escapeHtml(truncate(a.content_en,600))+'</div></div>':''}\${a.content_cn?'<div class="article-section translated"><div class="article-section-label">🇨🇳 译文摘录</div><div class="article-content">'+escapeHtml(truncate(a.content_cn,600))+'</div></div>':''}<div class="item-card-footer" style="margin-top:16px"><div class="flex gap-12">\${a.author?'<span>✍️ '+escapeHtml(a.author)+'</span>':''}\${a.read_time?'<span>⏱️ '+a.read_time+' 分钟阅读</span>':''}</div>\${a.url?'<a href="'+a.url+'" target="_blank" class="item-card-link">阅读原文 →</a>':''}</div></article>\`;
  }).join('');
  return '<div class="metrics-grid">'+metrics.map(i=>'<div class="metric-card '+i.color+'"><div class="metric-label">'+i.label+'</div><div class="metric-value">'+i.value+'</div></div>').join('')+'</div><div>'+articlesHtml+'</div>';
}

function switchTab(tabId){
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c=>c.classList.remove('active'));
  document.querySelector('[data-tab="'+tabId+'"]').classList.add('active');
  document.getElementById('tab-'+tabId).classList.add('active');
}

const DATA={llm:${llmJson},industry:${industryJson},intl:${intlJson}};
document.getElementById('llm-content').innerHTML=renderLLM(DATA.llm);
document.getElementById('industry-content').innerHTML=renderIndustry(DATA.industry);
document.getElementById('intl-content').innerHTML=renderIntl(DATA.intl);
`;

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>市场前沿信息 · 情报中枢</title>
<style>
${css}
${tabCss}
</style>
</head>
<body>
<nav class="navbar">
  <div class="navbar-brand">
    <div class="logo">M</div>
    <span>市场前沿信息</span>
    <span style="font-size:11px;color:var(--accent-cyan);padding:2px 8px;border:1px solid var(--accent-cyan);border-radius:4px;margin-left:8px">情报中枢</span>
  </div>
  <div class="navbar-nav"></div>
  <div class="navbar-right">
    <div class="status-dot"></div>
    <span class="mono">LIVE</span>
    <span style="margin-left:8px">2026-09-05</span>
  </div>
</nav>

<div class="container">
  <section class="home-hero" style="padding:32px 20px 20px">
    <h1 style="font-size:32px">市场前沿信息 · 情报中枢</h1>
    <p class="tagline">LLM 动态 / AI 全产业链 / 国际信息 · 三线情报</p>
    <p class="meta">// 数据快照 · 来源 OpenRouter / AIBase / The Batch / VentureBeat</p>
  </section>

  <div class="tab-bar">
    <button class="tab-btn active" data-tab="llm" onclick="switchTab('llm')">🤖 LLM 前沿动态</button>
    <button class="tab-btn" data-tab="industry" onclick="switchTab('industry')">🏭 AI 全产业链</button>
    <button class="tab-btn" data-tab="intl" onclick="switchTab('intl')">🌍 国际信息直连</button>
  </div>

  <div class="tab-content active" id="tab-llm"><div id="llm-content"></div></div>
  <div class="tab-content" id="tab-industry"><div id="industry-content"></div></div>
  <div class="tab-content" id="tab-intl"><div id="intl-content"></div></div>
</div>

<script>
${js}
</script>
</body>
</html>`;

fs.writeFileSync(path.join(ROOT, 'index.html'), html, 'utf8');
console.log('✅ 已生成单文件 HTML:', path.join(ROOT, 'index.html'));
console.log('   文件大小:', (html.length / 1024).toFixed(1) + ' KB');
