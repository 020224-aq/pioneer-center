
const FLOWS_RAW={
  buy:{
    due:['供应商背调','验货'],
    steps:{
      '供应商背调':[
        {n:'配置单核实',d:'核对供应商配置单是否符合服务器基本配置与我司需求（硬盘/网卡/IB卡/机头等）',o:'跟进商务'},
        {n:'主体背调',d:'核实公司注册时间、注册资金；核实中介交易证明真实性（避免白牌/皮包公司）',o:'先锋中心'},
        {n:'风险点核查',d:'质保范围（原厂/海外）、尾货风险、降配风险、交付周期是否可接受',o:'先锋中心'},
        {n:'合同条款约定',d:'约定验货方式、压测标准、付款节奏、自提/送货、维保与售后条款',o:'采购组'},
        {n:'付款条件评审',d:'订金比例是否合理；大额付款需银行保函或分阶段付款（参考央企 3%+27% 保函模式）',o:'财务 · 安琪'}
      ],
      '验货':[
        {n:'第三方验货',d:'安排第三方验货机构实地验货，核对型号/配置与原厂一致',o:'先锋中心'},
        {n:'防降配核对',d:'逐项核对 GPU 型号、显存、内存、硬盘、网卡与配置单一致',o:'运维'},
        {n:'专业压测',d:'自测或第三方专业压测：满载稳定性、功耗、散热、NVLink 互联',o:'运维'},
        {n:'付款交易',d:'验货压测通过后按合同完成付款（现场付款需核对账户主体）',o:'财务'},
        {n:'自提/交付',d:'现场自提或安排物流交付，确认收货与随附文件',o:'先锋中心'}
      ]
    }
  },
  rent:{
    due:['供应商背调','测试'],
    steps:{
      '供应商背调':[
        {n:'配置单核实',d:'核对租赁服务器配置（GPU 型号/显存/算力）与报价口径一致',o:'跟进商务'},
        {n:'主体背调',d:'核实出租方主体资质与机房产权/代理关系',o:'先锋中心'},
        {n:'部署地确认',d:'确认机房部署地（是否华南/就近）、网络线路质量',o:'运维'},
        {n:'合同条款约定',d:'租期、月租计费口径、带宽/IP 是否含、维保责任边界',o:'采购组'},
        {n:'违约与退出',d:'提前退租条款、设备损坏责任、数据安全与出域约定',o:'法务'}
      ],
      '测试':[
        {n:'环境开通',d:'确认机房通电、网络开通、远程管理可达',o:'运维'},
        {n:'性能测试',d:'实测算力/推理性能是否达标（对比官方算力值）',o:'运维'},
        {n:'稳定性测试',d:'满载 24h 以上稳定性、散热、降频情况',o:'运维'},
        {n:'网络/IB 测试',d:'训练内网 IB 互联、带宽实测',o:'运维'},
        {n:'验收起租',d:'测试通过后签署验收单，正式起租计费',o:'先锋中心'}
      ]
    }
  }
};

const BUY_H200=[
  {id:'bh1',src:'华硕',mod:'华硕 H200',ch:'企业',owner:'待分配',price:'现货 400 万',note:'渠道费另加 1 万 · 当前最低',risk:'',stock:'现货',conf:'—'},
  {id:'bh2',src:'组装厂',mod:'PCIe H200',ch:'国内组装厂',owner:'毛友琦',price:'420 万',note:'可盯产 · 可选配',risk:'主体不强，注册资金 200 万',stock:'期货',conf:'三年质保'},
  {id:'bh3',src:'香港数字资产研究院',mod:'超威 H200',ch:'企业',owner:'夏牧原',price:'现货 430 万 · 订金 30%',note:'网卡较多 · 硬盘居中',risk:'',stock:'现货',conf:'—'},
  {id:'bh4',src:'央企中间人',mod:'超威 H200',ch:'中介(国企签约)',owner:'毛友琦',price:'期货 460 万',note:'512 台 · 6-12 周交货 · 银行保函交易(3%+27%)',risk:'海外质保，国内无质保',stock:'期货',conf:'海外质保'},
  {id:'bh5',src:'中电数据产业集团',mod:'Lenovo WA5480 G3',ch:'企业直采',owner:'毛友琦',price:'现货 510 万',note:'60 台现货库存',risk:'网卡信息差异大 · 无 IB 卡',stock:'现货',conf:'3 年整机原厂保修'},
  {id:'bh6',src:'四川锐速科技',mod:'超微 H200',ch:'中介',owner:'陈增铭',price:'现货 525 万 · 订金 45%',note:'一个月内交付',risk:'',stock:'现货',conf:'—'},
  {id:'bh7',src:'四川锐速科技',mod:'同泰怡 8卡 H200 PCIE',ch:'中介',owner:'陈增铭',price:'现货 525 万 · 订金 30%',note:'现货 5 台 · 2 台已到成都',risk:'尾货 · 需确认完整质保',stock:'现货',conf:'网卡较少'},
  {id:'bh8',src:'天枢云',mod:'超威 SYS-421GE-TNRT Switch',ch:'中介',owner:'夏牧原',price:'现货 530 万 / 期货 317 万',note:'期货 6-8 周到货 · 能买能租',risk:'硬盘较小 · 无 IB 卡',stock:'现货+期货',conf:'—'},
  {id:'bh9',src:'杭州袭格玛',mod:'LCWT R9480（联创万通）',ch:'中介',owner:'夏牧原',price:'现货 545 万',note:'配置：8568Y*2 / 2T 内存 / 141G NVLINK*8 / CX7 400G IB*8 / 华勤机头',risk:'',stock:'现货',conf:'—'},
  {id:'bh10',src:'天翼云',mod:'H200（无型号）',ch:'中介',owner:'陈增铭',price:'现货 550 万 · 定金 60 万',note:'6 台 · 先看货→全款→压测',risk:'',stock:'现货',conf:'—'}
];

const BUY_B300=[
  {id:'bb1',src:'建润股份',mod:'DELL B300-2.3T 液冷版',ch:'中介',owner:'—',price:'1550 万',note:'需提供营业执照 + 验资后继续谈条件',risk:'高门槛 · 需验资',stock:'现货',conf:'液冷'},
  {id:'bb2',src:'洽谈中',mod:'超微 B300 3T 满配',ch:'—',owner:'先锋中心',price:'待报价',note:'持续寻源中',risk:'',stock:'—',conf:'—'}
];

const RENT_H200=[
  {id:'rh1',src:'天枢云',mod:'超威 SYS-421GE-TNRT Switch',ch:'中介(能买能租)',owner:'夏牧原',price:'11.8-12.1 万/月',note:'5 年起租 · 多地可选',risk:'',stock:'长租',conf:'新疆 12.1 / 贵州 11.8 / 山东 11.95 / 甘肃 11.95 万',deploy:'新疆/贵州/山东/甘肃 · 待问华南机房'}
];

const RENT_910=[
  {id:'r91a',src:'华为云',mod:'Atlas 800T A2',ch:'官方',owner:'何悦',price:'86 万/年',note:'NPU 280T · 贵阳/乌兰察布',risk:'官方原价 · 商务可议',stock:'按年/按需',conf:'显存 64G · 算力 280T',deploy:'贵阳/乌兰察布'},
  {id:'r91b',src:'华为云',mod:'Atlas 800T A2',ch:'官方',owner:'何悦',price:'136 万/年（5折可谈）',note:'313T · 商务议价可打 5 折',risk:'',stock:'按年/按需',conf:'显存 64G · 算力 313T',deploy:'贵阳/乌兰察布'},
  {id:'r91c',src:'华为云',mod:'Atlas 800T A2',ch:'官方',owner:'何悦',price:'156 万/年',note:'376T/400T 混装 · 同价无法自选算力',risk:'',stock:'按年/按需',conf:'显存 64G · 算力 376/400T',deploy:'贵阳/乌兰察布'},
  {id:'r91d',src:'华为云',mod:'Atlas 800T A3',ch:'官方',owner:'何悦',price:'239 万/年',note:'560T · 存量少需预约 · 审查资质+资金到账后走流程',risk:'需提前预约 · 无确定等待时长',stock:'按年/按需',conf:'显存 128G · 算力 560T',deploy:'贵阳/乌兰察布'},
  {id:'r91e',src:'华为云',mod:'Atlas 800T A3',ch:'官方',owner:'何悦',price:'266 万/年',note:'752T',risk:'',stock:'按年/按需',conf:'显存 128G · 算力 752T',deploy:'贵阳/乌兰察布'}
];

const TEAMS=[
  {n:'凡岛物业推荐工程队',bg:'物业推荐 · 新联系',st:'✅ 9/3 完成二轮现场勘测，12 楼定为本地首选点位',todo:'按 11 台满配出正式报价，预计 9/7 提交初版',pill:['run','勘测完成'],steps:['联系对接','实地勘测','改造方案','正式报价 9/7']},
  {n:'广州成迈网络科技',bg:'小红书找到 · 有改造服务器机房经验',st:'与工程队定好 9/7 完成现场一轮勘测',todo:'待勘测 → 出方案报价',pill:['wait','待勘测'],steps:['联系对接','现场勘测 9/7','改造方案','正式报价']},
  {n:'深圳易通技术',bg:'小红书找到 · 有改造经验',st:'不需线下勘测，提供机房照片给服务商出方案',todo:'发送机房照片 → 等方案',pill:['wait','待出方案'],steps:['联系对接','提供机房照片','改造方案','正式报价']},
  {n:'广州沃涵机电',bg:'11 楼改造曾合作工程队',st:'电话接通，但表示不承接改造业务',todo:'—',pill:['gray','不承接'],steps:['联系','评估','方案','报价']},
  {n:'霍江机电',bg:'11 楼改造曾对接 3 家之一',st:'电话未接通',todo:'继续联系或替换',pill:['gray','待联系'],steps:['联系','评估','方案','报价']}
];

const DECISIONS=[
  {n:'11 楼老机器是否迁移',d:'2 台机柜被楼层网线占用无法迁移',status:'待 9/3 内部会确认',pill:['wait','待拍板']},
  {n:'光纤 万兆 / 千兆',d:'组网带宽规格待定',status:'待拍板',pill:['wait','待拍板']},
  {n:'静电地板是否安装',d:'改造范围待确认',status:'待拍板',pill:['wait','待拍板']},
  {n:'机房恒温取舍',d:'空间恒温 vs 普通空调',status:'待拍板',pill:['wait','待拍板']},
  {n:'UPS 电池组承重方案',d:'5-6 吨超 12 楼承重 → 放负一楼低压配电房，线缆经电井上敷',status:'✅ 方案已定',pill:['ok','已定']}
];

const COLS=[
  {n:'杭州网鼎科技',loc:'杭州 / 宁波',price:'杭州 700元/kW/月 ≈11.83万/月 · 宁波 650元/kW/月 ≈10.99万/月',bw:'赠 100M 电信独享',cool:'风冷+液冷 · 单柜制冷 ≥150kW · 冷通道 19-25℃',pow:'定制单机柜承受电力',ib:'可协助组网',st:['run','已报价']},
  {n:'上海欧网',loc:'江苏扬州(液冷) / 上海(高电30A)',price:'液冷机柜 950元/kW/月 · 高电机柜按耗电量计',bw:'带宽 IP 另计费 · 移动/电信/联通 BGP',cool:'风冷+液冷 · 背板 8kW / 列间 40kW',pow:'液冷 20kW 单机柜双路 / 风冷 6-8kW',ib:'IB 组网单独收费',st:['wait','待确认配套机器后出报价']},
  {n:'无忧云（广州云硕）',loc:'广州',price:'800 元/kVA/月 · 带宽 IP 另计',bw:'带宽 IP 另计',cool:'精密空调 · 制冷 75kW / 功率 3.2kW（可改造）',pow:'按 kVA',ib:'不协助组网',st:['run','已报价']},
  {n:'无忧云（深圳百旺信）',loc:'深圳',price:'1000 元/kVA/月 · 带宽 IP 另计',bw:'带宽 IP 另计',cool:'精密空调 · 制冷可改造',pow:'按 kVA',ib:'不协助组网',st:['run','已报价']},
  {n:'蔚蓝智谷',loc:'江门',price:'800 元/kVA/月 · 带宽 IP 另计',bw:'带宽 IP 另计',cool:'精密空调 · 单台制冷 153kW',pow:'按 kVA',ib:'—',st:['run','已报价']},
  {n:'河南亿恩科技',loc:'广州南沙',price:'880 元/kVA/月 · 带宽 IP 另计',bw:'带宽 IP 另计',cool:'精密空调',pow:'按 kVA',ib:'可协助组网',st:['run','已报价']},
  {n:'四川众诚无限科技',loc:'四川雅安(算力推荐) / 云南呈贡',price:'AI 部门未给带宽/IP 需求 · 暂无法报价',bw:'—',cool:'—',pow:'—',ib:'—',st:['gray','待需求']},
  {n:'京东',loc:'全国',price:'AI 部门未给带宽/IP 需求 · 暂无法报价',bw:'—',cool:'—',pow:'—',ib:'—',st:['gray','待需求']},
  {n:'中国电信',loc:'广州各区 / 韶关',price:'AI 部门未给带宽/IP 需求 · 暂无法报价',bw:'双路/多路变电站接入',cool:'可按指标匹配机房',pow:'据需匹配',ib:'不提供 · 客户自行组网',st:['gray','待需求']},
  {n:'中国移动',loc:'移动南方基地',price:'AI 部门未给带宽/IP 需求 · 暂无法报价',bw:'—',cool:'—',pow:'—',ib:'—',st:['gray','待需求']},
  {n:'广东天耘科技',loc:'广州 / 深圳',price:'AI 部门未给带宽/IP 需求 · 暂无法报价',bw:'—',cool:'—',pow:'—',ib:'—',st:['gray','待需求']}
];

/* ============ 工具 ============ */
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
const LS='shub-state-v1';
let CUR='';

/* ---------- 基础数据（含备份 FLOWS 兜底） ---------- */
const FALL_FLOWS={buy:{steps:{'供应商背调':[{n:'工商/背景核查',d:'确认公司主体与经营范围',o:'采购组'},{n:'交易记录背调',d:'历史成交与口碑',o:'采购组'},{n:'资质与报价单',d:'索要配置单与报价',o:'采购组'}],'验货':[{n:'验配置单',d:'核对型号与配置',o:'验收组'},{n:'外观开箱检查',d:'检查外观与序列号',o:'验收组'},{n:'上电自检',d:'点亮与基础跑分',o:'验收组'}]}},rent:{steps:{'供应商背调':[{n:'工商/背景核查',d:'确认公司主体',o:'采购组'},{n:'机房实地确认',d:'确认机房与冗余',o:'采购组'}],'测试':[{n:'算力基准测试',d:'跑分对比规格',o:'测试组'},{n:'稳定性压测',d:'满载稳定性',o:'测试组'}]}}};
const FLOWS=(typeof FLOWS_RAW!=='undefined'&&FLOWS_RAW)?FLOWS_RAW:FALL_FLOWS;
const FLOW_ORDER={buy:['供应商背调','验货'],rent:['供应商背调','测试']};

/* ============ 数据桥：接真实数据库（优先） / 回退内联（离线） ============ */
function mapDbQuote(q, kind){
  // 把数据库 pc_quotes 行 → 服务器采购卡片对象
  const priceTxt = kind === 'rent' ? (q.price + ' ' + (q.unit || '万/年')) : (q.type === '期货' ? ('期货 ' + q.price + ' 万') : ('现货 ' + q.price + ' 万'));
  return {
    id: q.id, src: q.channel || '未署名', mod: q.asset_name || q.asset || '',
    ch: q.type || '—', owner: '—', price: priceTxt,
    note: q.cond || '', risk: '', stock: q.type || '—', conf: '—',
  };
}
function applyDbData(){
  const db = window.__DB__;
  if (!db || !db.serverBoard || !db.serverBoard.length) return false;
  const board = db.serverBoard[0]; // p1 服务器采购
  const quotes = board.quotes || [];
  const buy = quotes.filter(q => q.track === 'buy' && q.cat === 'server');
  const rent = quotes.filter(q => q.track === 'lease');
  const h200 = buy.filter(q => /H200/.test(q.asset));
  const b300 = buy.filter(q => /B300/.test(q.asset));
  const h200rent = rent.filter(q => /H200|超威|天枢/.test(q.asset_name || q.asset));
  const atlas = rent.filter(q => /Atlas|昇腾|910|950/.test(q.asset_name || q.asset));
  const other = buy.filter(q => !/H200/.test(q.asset) && !/B300/.test(q.asset));
  // 覆盖购买 H200 / B300 / 其他(合并进 H200 列表展示) / 租赁 H200 / 租赁 Atlas
  if (h200.length || other.length) {
    BUY_H200.splice(0, BUY_H200.length);
    h200.concat(other).forEach(q => BUY_H200.push(mapDbQuote(q, 'buy')));
  }
  if (b300.length) {
    BUY_B300.splice(0, BUY_B300.length);
    b300.forEach(q => BUY_B300.push(mapDbQuote(q, 'buy')));
  }
  if (h200rent.length) {
    RENT_H200.splice(0, RENT_H200.length);
    h200rent.forEach(q => RENT_H200.push(Object.assign(mapDbQuote(q, 'rent'), { deploy: q.cond || '' })));
  }
  if (atlas.length) {
    RENT_910.splice(0, RENT_910.length);
    atlas.forEach(q => RENT_910.push(Object.assign(mapDbQuote(q, 'rent'), { deploy: q.cond || '' })));
  }
  return true;
}
// 数据到达后应用（app.js 由 bridge 在数据就绪后才动态加载，此时 __DB__ 一定已就绪）
applyDbData();
window.addEventListener('db-ready', () => { applyDbData(); });

/* ---------- 持久化 ---------- */
let store={done:{},added:{buy:[],rent:[],teams:[],colos:[]}};
loadStore();
function loadStore(){try{store=JSON.parse(localStorage.getItem(LS))}catch(e){}
  if(!store||typeof store!=='object')store={done:{},added:{buy:[],rent:[],teams:[],colos:[]}};
  if(!store.done)store.done={};
  if(!store.added)store.added={buy:[],rent:[],teams:[],colos:[]};
}
function saveStore(){try{localStorage.setItem(LS,JSON.stringify(store))}catch(e){}}
function keyDone(mode,vid,stage,step){return mode+'|'+vid+'|'+stage+'|'+step}
function stageDoneNum(mode,vid,stage){
  const list=(FLOWS[mode]&&FLOWS[mode].steps[stage])||[];
  return list.filter(s=>store.done[keyDone(mode,vid,stage,s.n)]).length;
}
function stageTotal(mode,stage){return ((FLOWS[mode]&&FLOWS[mode].steps[stage])||[]).length}
function stageAllDone(mode,vid,stage){
  const t=stageTotal(mode,stage);return t>0&&stageDoneNum(mode,vid,stage)>=t;
}
function toggleStage(mode,vid,stage){
  const list=(FLOWS[mode]&&FLOWS[mode].steps[stage])||[];
  const all=stageAllDone(mode,vid,stage);
  list.forEach(s=>{store.done[keyDone(mode,vid,stage,s.n)]=!all});
  saveStore();
}

/* ---------- 步骤级逐项勾选 ---------- */
function stepPanelId(mode,vid,stage){return 'panel_'+mode+'_'+vid+'_'+stage}
function stepPanelHtml(mode,vid,stage){
  const list=(FLOWS[mode]&&FLOWS[mode].steps[stage])||[];
  if(!list.length)return '';
  const rows=list.map(s=>{
    const k=keyDone(mode,vid,stage,s.n);
    const d=!!store.done[k];
    return '<div class="stepline '+(d?'done':'')+'" onclick="toggleStep(\''+mode+'\',\''+vid+'\',\''+stage+'\',\''+s.n.replace(/'/g,'')+'\')">'+
      '<span class="cb">'+(d?'✓':'')+'</span>'+
      '<span class="st"><b>'+s.n+'</b>'+(s.d?'<small>'+s.d+'</small>':'')+'</span>'+
      '<span class="so">'+(s.o||'')+'</span>'+
    '</div>';
  }).join('');
  const all=stageAllDone(mode,vid,stage);
  return '<div class="steppanel" id="'+stepPanelId(mode,vid,stage)+'">'+rows+
    '<div style="display:flex;justify-content:space-between;align-items:center;padding:9px 15px">'+
    '<span style="font-size:11px;color:var(--ink3);font-family:var(--mono)">'+(stageDoneNum(mode,vid,stage))+'/'+stageTotal(mode,stage)+' 已完成</span>'+
    '<button class="btn ghost small" onclick="event.stopPropagation();toggleStage(\''+mode+'\',\''+vid+'\',\''+stage+'\');refreshStagePanels(\''+mode+'\',\''+vid+'\')">'+(all?'全部取消':'一键完成')+'</button>'+
    '</div></div>';
}
function openStage(mode,vid,stage){
  const panel=document.getElementById(stepPanelId(mode,vid,stage));
  if(!panel)return;
  panel.classList.toggle('open');
}
function toggleStep(mode,vid,stage,step){
  const k=keyDone(mode,vid,stage,step);
  store.done[k]=!store.done[k];
  saveStore();
  refreshStagePanels(mode,vid);
}
function refreshStagePanels(mode,vid){
  // 1) 刷新该供应商的阶段徽章计数与步骤面板
  const stageS=FLOW_ORDER[mode]||[];
  stageS.forEach(st=>{
    const panel=document.getElementById(stepPanelId(mode,vid,st));
    if(panel){
      const wasOpen=panel.classList.contains('open');
      const tmp=document.createElement('div');
      tmp.innerHTML=stepPanelHtml(mode,vid,st);
      const fresh=tmp.firstElementChild;
      if(wasOpen)fresh.classList.add('open');
      panel.parentNode.replaceChild(fresh,panel);
    }
  });
  // 2) 刷新该供应商的阶段徽章(找到该供应商卡片容器内的 .stp)
  const row=document.querySelector('[data-vid="'+mode+'|'+vid+'"]');
  if(row){
    const stps=row.querySelectorAll('.qbar .stp');
    stageS.forEach((st,i)=>{
      const dN=stageDoneNum(mode,vid,st),tN=stageTotal(mode,st),all=stageAllDone(mode,vid,st);
      if(stps[i])stps[i].outerHTML='<button class="stp '+(all?'done':'')+'" onclick="openStage(\''+mode+'\',\''+vid+'\',\''+st+'\')">'+(all?'✓ ':'')+st+'<span class="pr">'+dN+'/'+tN+'</span></button>';
    });
    row.classList.toggle('done',stageS.length>0&&stageS.every(st=>stageAllDone(mode,vid,st)));
  }
}
function getActiveTabKey(mode){
  const on=$('.mtab.on');
  if(!on)return 'ALL';
  const txt=on.textContent;
  if(txt.indexOf('H200')>=0)return 'H200';
  if(txt.indexOf('B300')>=0)return 'B300';
  if(txt.indexOf('910')>=0||txt.indexOf('Atlas')>=0)return '910';
  return 'ALL';
}

/* ---------- 合并新增数据 ---------- */
const ALL={buyH:[...(typeof BUY_H200!=='undefined'?BUY_H200:[]),...store.added.buy.filter(x=>x.grp==='H200')],
  buyB:[...(typeof BUY_B300!=='undefined'?BUY_B300:[]),...store.added.buy.filter(x=>x.grp==='B300')],
  rentH:[...(typeof RENT_H200!=='undefined'?RENT_H200:[]),...store.added.rent.filter(x=>x.grp==='H200')],
  rentA:[...(typeof RENT_910!=='undefined'?RENT_910:[]),...store.added.rent.filter(x=>x.grp==='910')],
  teams:[...(typeof TEAMS!=='undefined'?TEAMS:[]),...store.added.teams],
  colos:[...(typeof COLS!=='undefined'?COLS:[]),...store.added.colos],
  decis:(typeof DECISIONS!=='undefined')?DECISIONS:[]};
const ADD=store.added;

/* ---------- 主题 ---------- */
function toggleTheme(){
  const el=document.documentElement;
  const d=el.getAttribute('data-theme')==='dark';
  el.setAttribute('data-theme',d?'light':'dark');
  $('#themeBtn').textContent=d?'◐':'☾';
  localStorage.setItem('shub-theme',d?'light':'dark');
}
(function(){const t=localStorage.getItem('shub-theme');if(t){document.documentElement.setAttribute('data-theme',t);$('#themeBtn').textContent=t==='dark'?'☾':'◐'}})();

/* ---------- 导航高亮 ---------- */
function scrollToId(id){
  const el=document.getElementById(id);
  if(el)el.scrollIntoView({behavior:RM?'auto':'smooth',block:'start'});
}
const navIO=new IntersectionObserver(es=>es.forEach(e=>{
  if(e.isIntersecting){$$('.navlinks a').forEach(a=>a.classList.toggle('on',a.dataset.s===e.target.id))}
}),{rootMargin:'-45% 0px -50% 0px'});
['top','procure','deploy'].forEach(id=>{const el=document.getElementById(id);if(el)navIO.observe(el)});

/* ---------- Reveal ---------- */
const rvIO=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');rvIO.unobserve(e.target)}}),{threshold:.12,rootMargin:'0px 0px -6% 0px'});
function bindReveals(){$$('.rv:not(.in)').forEach(el=>rvIO.observe(el))}

/* ---------- 视差（Hero） ---------- */
if(!RM&&'IntersectionObserver' in window){
  const hw=$('#heroWrap');
  addEventListener('scroll',()=>{
    const y=scrollY;
    if(y<window.innerHeight*1.4){
      hw.style.transform='translateY('+(y*.16)+'px)';
      hw.style.opacity=Math.max(0,1-y/(window.innerHeight*.95));
    }
  },{passive:true});
}

/* ---------- 卡片内文案 ---------- */
function qRowHtml(v,mode,groups){
  const stages=FLOW_ORDER[mode]||[];
  const stageChips=stages.map(st=>{
    const dN=stageDoneNum(mode,v.id,st),tN=stageTotal(mode,st),all=stageAllDone(mode,v.id,st);
    return '<button class="stp '+(all?'done':'')+'" onclick="openStage(\''+mode+'\',\''+v.id+'\',\''+st+'\')">'+(all?'✓ ':'')+st+'<span class="pr">'+dN+'/'+tN+'</span></button>';
  }).join('');
  const stagePanels=stages.map(st=>{return stepPanelHtml(mode,v.id,st)}).join('');
  const chips=[];
  if(v.stock)chips.push('<span class="mini n">'+v.stock+'</span>');
  if(v.conf&&v.conf!=='—')chips.push('<span class="mini">'+v.conf+'</span>');
  const allS=stages.length>0&&stages.every(st=>stageAllDone(mode,v.id,st));
  return '<div class="qrow '+(allS?'done':'')+'" data-vid="'+mode+'|'+v.id+'">'+
    '<div class="qh"><div class="qn">'+v.mod+'<small>'+v.src+' · '+(v.ch||'—')+(v.owner&&v.owner!=='—'?' · 跟进 '+v.owner:'')+'</small></div>'+
    '<div class="qp">'+String(v.price||'—').replace('万','<small>万</small>').replace('月','<small>/月</small>').replace('年','<small>/年</small>')+'</div></div>'+
    (chips.length?'<div class="qmeta">'+chips.join('')+'</div>':'')+
    (v.risk&&v.risk!=='—'?'<div class="qnote warn">⚠ '+v.risk+'</div>':'')+
    (v.note&&v.note!=='—'?'<div class="qnote">'+v.note+'</div>':'')+
    (v.deploy&&v.deploy!=='—'?'<div class="qown">📍 '+v.deploy+'</div>':'')+
    (stageChips?'<div class="qbar">'+stageChips+'</div>':'')+
    stagePanels+
    '<div class="acts"><button class="btn ghost small" onclick="delAdded(\''+mode+'\',\''+groups+'\',\''+(v._added?v._added:'')+'\')">删除</button></div>'+
  '</div>';
}

/* ---------- 报价弹窗 ---------- */
const QUOTE_CFG={
  buy:{title:'购买渠道 · 全部报价',sub:'背调 → 验货 流程卡点，点击阶段徽章可标记完成',groups:[['H200','buyH','NVIDIA H200'],['B300','buyB','NVIDIA B300']]},
  rent:{title:'租赁渠道 · 全部报价',sub:'背调 → 算力测试 流程卡点，点击阶段徽章可标记完成',groups:[['H200','rentH','NVIDIA H200 · 长租'],['910','rentA','华为 Atlas 800 · NPU 租赁']]}
};
function openQuotes(mode){
  CUR=mode;
  const cfg=QUOTE_CFG[mode];
  $('#mTitle').textContent=cfg.title;
  $('#mSub').textContent=cfg.sub;
  $('#mFoot').innerHTML='';
  $('#mBody').innerHTML=renderQuoteInner(mode,'ALL');
  $('#ov').classList.add('on');
  document.body.style.overflow='hidden';
  bindReveals();
}
function renderQuoteInner(mode,sel){
  const cfg=QUOTE_CFG[mode];
  const tabs='<div class="mtabs"><button class="mtab '+(sel==='ALL'?'on':'')+'" onclick="rerenderQuote(\''+mode+'\',\'ALL\')">全部</button>'+
    cfg.groups.map(g=>'<button class="mtab '+(sel===g[0]?'on':'')+'" onclick="rerenderQuote(\''+mode+'\',\''+g[0]+'\')">'+g[2]+'<span class="c">'+ALL[g[1]].length+'</span></button>').join('')+'</div>';
  let body=tabs;
  cfg.groups.forEach(g=>{
    if(sel!=='ALL'&&sel!==g[0])return;
    const list=ALL[g[1]];
    if(!list.length){body+='<div class="qrow" style="color:var(--ink3)">暂无 '+g[2]+' 渠道数据</div>';return}
    body+='<div class="msec-l"><span class="dot"></span>'+g[2]+'<small>'+list.length+' 条</small></div>'+list.map(v=>qRowHtml(v,mode,g[0])).join('');
  });
  return body;
}
function rerenderQuote(mode,sel){
  if(!$('#ov').classList.contains('on')||CUR!==mode)return;
  $('#mBody').innerHTML=renderQuoteInner(mode,sel);
}

/* ---------- 删除新增数据 ---------- */
function delAdded(mode,grp,uid){
  if(!uid)return;
  const map={buy:['buyH','buyB'],rent:['rentH','rentA']};
  const key=grp==='H200'?'buyH':grp==='B300'?'buyB':grp==='910'?'rentA':'rentH';
  ADD[mode]=ADD[mode].filter(x=>x._added!==uid);
  saveStore();
  toast('已删除该渠道');
  rerenderQuote(mode,'ALL');
}

/* ---------- 工程队弹窗 ---------- */
function teamCardHtml(t){
  const list=t.steps||[];
  const key='team|'+t.n;
  const doneN=list.filter(s=>store.done[key+'|'+s]).length;
  const pct=list.length?Math.round(doneN/list.length*100):0;
  const chips=list.map(s=>{
    const d=store.done[key+'|'+s];
    return '<button class="stp '+(d?'done':'')+'" onclick="toggleTeam(\''+t.n.replace(/'/g,'')+'\',\''+s.replace(/'/g,'')+'\');openTeams()">'+(d?'✓ ':'')+s+'</button>';
  }).join('');
  return '<div class="qrow"><div class="qh"><div class="qn">'+t.n+'<small>'+t.bg+'</small></div>'+
    '<span class="mini '+(t.pill&&t.pill[0]==='run'?'':(t.pill&&t.pill[0]==='wait'?'a':(t.pill&&t.pill[0]==='ok'?'g':'n')))+'">'+((t.pill&&t.pill[1])||'—')+'</span></div>'+
    '<div class="qnote">'+t.st+'</div>'+
    (t.todo&&t.todo!=='—'?'<div class="qnote">待跟进：'+t.todo+'</div>':'')+
    (list.length?'<div class="qbar">'+chips+'</div><div class="qown">进度 '+doneN+'/'+list.length+' · '+pct+'%</div>':'')+
    '<div class="acts"><button class="btn ghost small" onclick="delAdded(\'teams\')">删除</button></div></div>';
}
function toggleTeam(n,s){
  const key='team|'+n+'|'+s;
  store.done[key]=!store.done[key];
  saveStore();
}
function openTeams(){
  CUR='teams';
  $('#mTitle').textContent='本地部署 · 工程队进度';
  $('#mSub').textContent='本地 12F 机房改造，逐项标记施工进度';
  $('#mFoot').innerHTML='<button class="btn ghost" onclick="openForm(\'team\')">＋ 新增工程队</button>';
  $('#mBody').innerHTML='<div class="msec-l"><span class="dot"></span>工程队<small>'+ALL.teams.length+' 家</small></div>'+
    (ALL.teams.length?ALL.teams.map(t=>teamCardHtml(t)).join(''):'<div class="qrow" style="color:var(--ink3)">暂无工程队</div>');
  $('#ov').classList.add('on');
  document.body.style.overflow='hidden';
}

/* ---------- 托管商弹窗 ---------- */
function coloCardHtml(c){
  return '<div class="qrow"><div class="qh"><div class="qn">'+c.n+'<small>📍 '+(c.loc||'—')+'</small></div>'+
    '<span class="mini '+(c.st&&c.st[0]==='run'?'':(c.st&&c.st[0]==='wait'?'a':'n'))+'">'+((c.st&&c.st[1])||'—')+'</span></div>'+
    '<div style="margin-top:10px">'+
    '<div class="dline"><span class="k">价格</span><span class="v" style="color:var(--blue)">'+(c.price||'—')+'</span></div>'+
    '<div class="dline"><span class="k">带宽</span><span class="v">'+(c.bw||'—')+'</span></div>'+
    '<div class="dline"><span class="k">制冷</span><span class="v">'+(c.cool||'—')+'</span></div>'+
    '<div class="dline"><span class="k">供电</span><span class="v">'+(c.pow||'—')+'</span></div>'+
    '<div class="dline"><span class="k">IB 组网</span><span class="v">'+(c.ib||'—')+'</span></div></div>'+
    '<div class="acts"><button class="btn ghost small" onclick="delAdded(\'colos\')">删除</button></div></div>';
}
function openColos(){
  CUR='colos';
  $('#mTitle').textContent='外部托管 · 供应商报价对比';
  $('#mSub').textContent='统一换算月度总成本后比选；确认 IB 组网 / 功率密度 / 双路冗余';
  $('#mFoot').innerHTML='<button class="btn ghost" onclick="openForm(\'colo\')">＋ 新增托管商</button>';
  $('#mBody').innerHTML='<div class="msec-l"><span class="dot"></span>托管商<small>'+ALL.colos.length+' 家</small></div>'+
    (ALL.colos.length?ALL.colos.map(c=>coloCardHtml(c)).join(''):'<div class="qrow" style="color:var(--ink3)">暂无托管商</div>');
  $('#ov').classList.add('on');
  document.body.style.overflow='hidden';
}

/* ---------- 关键决策 ---------- */
function openDecisions(){
  CUR='decis';
  $('#mTitle').textContent='本地部署 · 待拍板关键项';
  $('#mSub').textContent='已定与待定事项';
  $('#mFoot').innerHTML='';
  $('#mBody').innerHTML=ALL.decis.map(d=>{
    return '<div class="qrow"><div class="qh"><div class="qn">'+d.n+'</div><span class="mini '+(d.pill&&d.pill[0]==='ok'?'g':(d.pill&&d.pill[0]==='wait'?'a':'n'))+'">'+((d.pill&&d.pill[1])||'—')+'</span></div><div class="qnote">'+d.d+'</div>'+(d.status?'<div class="qown">'+d.status+'</div>':'')+'</div>';
  }).join('');
  $('#ov').classList.add('on');
  document.body.style.overflow='hidden';
}

/* ---------- 表单 ---------- */
let FORM={};
function openForm(type,mode){
  CUR='form-'+type;
  FORM={type,mode};
  let title='',sub='',html='';
  if(type==='supplier'){
    title=mode==='buy'?'新增服务商':'新增租赁渠道';
    sub='录入后立即出现在对应渠道列表中（本地保存）';
    html='<div class="fgrid">'+
      '<div class="fld full"><label>名称 / 服务商</label><input id="f_name" placeholder="例如：华硕渠道商 / 天枢云"></div>'+
      '<div class="fld"><label>型号分类</label><select id="f_grp">'+(mode==='buy'?'<option value="H200">NVIDIA H200</option><option value="B300">NVIDIA B300</option>':'<option value="H200">NVIDIA H200 · 长租</option><option value="910">华为 Atlas 800 / NPU</option>')+'</select></div>'+
      '<div class="fld"><label>渠道类型</label><select id="f_ch"><option>企业直采</option><option>中介</option><option>官方</option><option>代理商</option></select></div>'+
      '<div class="fld"><label>报价</label><input id="f_price" placeholder="例如：510 万 或 12 万/月"></div>'+
      '<div class="fld"><label>货期 / 库存</label><input id="f_stock" placeholder="现货 / 期货 6-8 周"></div>'+
      '<div class="fld full"><label>备注</label><textarea id="f_note" placeholder="配置、风险、对接人…"></textarea></div>'+
    '</div>';
  }else if(type==='team'){
    title='新增工程队';
    sub='本地改造候选工程队';
    html='<div class="fgrid">'+
      '<div class="fld full"><label>工程队名称</label><input id="f_name" placeholder="例如：广州成迈网络科技"></div>'+
      '<div class="fld full"><label>来源 / 背景</label><input id="f_bg" placeholder="小红书 / 物业推荐 / 曾合作…"></div>'+
      '<div class="fld full"><label>当前进展</label><textarea id="f_st" placeholder="已联系？已勘测？待出方案？"></textarea></div>'+
    '</div>';
  }else if(type==='colo'){
    title='新增托管商';
    sub='报价将出现在托管对比列表';
    html='<div class="fgrid">'+
      '<div class="fld"><label>名称</label><input id="f_name" placeholder="例如：杭州网鼎科技"></div>'+
      '<div class="fld"><label>机房位置</label><input id="f_loc" placeholder="杭州 / 宁波"></div>'+
      '<div class="fld full"><label>价格口径</label><input id="f_price" placeholder="700 元/kW/月 ≈ 11.83 万/月"></div>'+
      '<div class="fld"><label>带宽</label><input id="f_bw" placeholder="赠 100M 电信独享"></div>'+
      '<div class="fld"><label>IB 组网</label><select id="f_ib"><option>可协助组网</option><option>不协助组网</option><option>单独收费</option></select></div>'+
    '</div>';
  }
  $('#mTitle').textContent=title;
  $('#mSub').textContent=sub;
  $('#mBody').innerHTML=html+'<div class="formacts"><button class="btn ghost" onclick="closeModal()">取消</button><button class="btn solid" onclick="submitForm()">保存并添加</button></div>';
  $('#mFoot').innerHTML='';
  $('#ov').classList.add('on');
  document.body.style.overflow='hidden';
}
function submitForm(){
  const val=id=>{const el=document.getElementById(id);return el?el.value.trim():''};
  const name=val('f_name');
  if(!name){toast('请填写名称');return}
  const t=FORM.type;
  if(t==='supplier'){
    const grp=val('f_grp');
    const obj={id:'u'+Date.now(),src:name,mod:grp==='910'?'Atlas 800T A2（新渠道）':(grp==='H200'?'H200（新渠道）':'B300（新渠道）'),ch:val('f_ch')||'中介',owner:'我',price:val('f_price')||'待报价',note:val('f_note')||'—',risk:'',stock:val('f_stock')||'—',conf:'—',_added:'u'+Date.now(),grp};
    ADD[FORM.mode].push(obj);
  }else if(t==='team'){
    ADD.teams.push({n:name,bg:val('f_bg')||'—',st:val('f_st')||'—',todo:'—',pill:['wait','新录入'],steps:['联系','评估','方案','报价'],_added:'u'+Date.now()});
  }else if(t==='colo'){
    ADD.colos.push({n:name,loc:val('f_loc')||'—',price:val('f_price')||'待需求',bw:val('f_bw')||'—',cool:'—',pow:'—',ib:val('f_ib')||'—',st:['wait','已录入'],_added:'u'+Date.now()});
  }
  saveStore();
  toast('已添加：'+name);
  if(t==='supplier'){openQuotes(FORM.mode)}
  else if(t==='team'){openTeams()}
  else if(t==='colo'){openColos()}
}
function closeModal(){$('#ov').classList.remove('on');document.body.style.overflow=''}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});

/* ---------- Toast ---------- */
let toastTimer=null;
function toast(msg){
  const t=$('#toast');
  t.textContent=msg;t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>t.classList.remove('on'),2400);
}

/* ---------- init ---------- */
bindReveals();
setTimeout(bindReveals,300);
setTimeout(()=>{$$('.rv').forEach(el=>el.classList.add('in'))},1800);
