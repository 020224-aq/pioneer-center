-- 先锋中心 · 采购资源中枢 —— 数据库 Schema(信息架构定义)
-- 四大板块对应四张核心表,字段基于 2026/9 真实业务文档提炼。

PRAGMA journal_mode = WAL;

-- ============ 板块一:大模型采购 ============
CREATE TABLE IF NOT EXISTS model_quotes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  model_name    TEXT NOT NULL,             -- 模型名(如 DeepSeek-V4-Flash-0731)
  vendor        TEXT NOT NULL,             -- 厂商/渠道(阿里云/腾讯云/京东/火山/华为云/官方/中转站)
  channel_type  TEXT DEFAULT '云厂商',     -- 渠道类型:官方/云厂商/中转站/自建
  input_price   REAL,                      -- 综合输入价(元/百万 tokens)
  output_price  REAL,                      -- 输出价(元/百万 tokens)
  cache_hit_price    REAL,                 -- 缓存命中价
  cache_miss_price   REAL,                 -- 缓存未命中价
  price_factor  REAL,                      -- 价格系数(基准 DeepSeek 官方 = 1.0)
  save_pct      REAL,                      -- 对比官方节省百分比(正=省,负=贵)
  tpm           TEXT,                      -- TPM 额度(如 "120万")
  quote_date    TEXT,                      -- 报价时间(YYYY-MM-DD)
  conditions    TEXT,                      -- 条件/备注(保底年框、合同、稳定性等)
  status        TEXT DEFAULT '已报价',     -- 状态:已报价/谈判中/首选/已合作/放弃
  owner         TEXT,                      -- 负责人
  created_at    TEXT DEFAULT (datetime('now','localtime')),
  updated_at    TEXT DEFAULT (datetime('now','localtime'))
);

-- ============ 板块二:服务器采购 ============
CREATE TABLE IF NOT EXISTS server_quotes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  chip_model    TEXT NOT NULL,             -- 芯片型号:H200 / B300 / MI300X / 950PR / 950DT
  server_model  TEXT,                      -- 服务器具体型号(如 超威SYS-421GE-TNRT)
  channel_type  TEXT DEFAULT '中介',       -- 渠道类型:中介/企业直采/国内组装厂/租赁
  channel_name  TEXT,                      -- 渠道/货主名称
  price_type    TEXT DEFAULT '现货',       -- 现货 / 期货
  unit_price    REAL,                      -- 报价(单台,万元)
  deposit       TEXT,                      -- 订金(如 "30%"/"60万")
  delivery      TEXT,                      -- 交付周期(如 "6-8周到货")
  stock         TEXT,                      -- 库存(如 "现货20台")
  quote_date    TEXT,                      -- 报价时间
  config_note   TEXT,                      -- 配置单/备注(链接或说明)
  risk_level    TEXT DEFAULT '待评估',     -- 风险等级:待评估/低/中/高
  status        TEXT DEFAULT '寻源中',     -- 状态:寻源中/已核实/候选/已排除/已合作
  owner         TEXT,
  created_at    TEXT DEFAULT (datetime('now','localtime')),
  updated_at    TEXT DEFAULT (datetime('now','localtime'))
);

-- ============ 板块三:供应商资源库 ============
CREATE TABLE IF NOT EXISTS suppliers (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT NOT NULL,           -- 供应商名称
  type            TEXT,                    -- 类型:中介/厂商/企业直采/组装厂/托管商/工程队/云厂商
  category        TEXT,                    -- 所属类别:大模型/服务器/托管/工程/综合
  contact         TEXT,                    -- 联系人
  contact_info    TEXT,                    -- 联系方式(电话/微信)
  reg_capital     TEXT,                    -- 注册资本
  founded         TEXT,                    -- 注册时间
  background_check TEXT DEFAULT '未背调',  -- 背调状态:未背调/背调中/已通过/存疑
  rating          INTEGER DEFAULT 0,       -- 评级(1-5)
  main_business   TEXT,                    -- 主营业务
  risk_note       TEXT,                    -- 风险备注
  status          TEXT DEFAULT '待评估',   -- 合作状态:待评估/接触中/已合作/已排除
  owner           TEXT,
  created_at      TEXT DEFAULT (datetime('now','localtime')),
  updated_at      TEXT DEFAULT (datetime('now','localtime'))
);

-- ============ 板块四:市场前沿信息 ============
CREATE TABLE IF NOT EXISTS market_intel (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  title         TEXT NOT NULL,             -- 标题
  category      TEXT DEFAULT '行业动态',   -- 分类:芯片路标/行业动态/调研报告/模型动态/政策
  source        TEXT,                      -- 来源
  url           TEXT,                      -- 链接
  summary       TEXT,                      -- 摘要
  publish_date  TEXT,                      -- 发布日期
  tags          TEXT,                      -- 标签(逗号分隔)
  importance    TEXT DEFAULT '中',         -- 重要度:高/中/低
  status        TEXT DEFAULT '待阅',       -- 状态:待阅/已阅/已归档
  owner         TEXT,
  created_at    TEXT DEFAULT (datetime('now','localtime')),
  updated_at    TEXT DEFAULT (datetime('now','localtime'))
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_model_vendor   ON model_quotes(vendor);
CREATE INDEX IF NOT EXISTS idx_model_name     ON model_quotes(model_name);
CREATE INDEX IF NOT EXISTS idx_server_chip    ON server_quotes(chip_model);
CREATE INDEX IF NOT EXISTS idx_supplier_type  ON suppliers(type);
CREATE INDEX IF NOT EXISTS idx_intel_category ON market_intel(category);
