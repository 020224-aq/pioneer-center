// 先锋中心 · 采购资源中枢 —— 后端入口(MySQL 版)
// 对接市场拓展部 MySQL 的 pc_ 系列表(pc_projects/pc_tracks/pc_quotes/pc_channels/pc_assets/pc_tasks/pc_feed/pc_blockers/pc_intel)
// 连接配置读取 .env(本地),勿提交含密码文件到共享环境
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const mysql = require('mysql2/promise');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 5173);

// ---- 读取 .env(简单解析,不引入 dotenv 亦可;此处支持 dotenv 若有) ----
function loadEnv() {
  try { require('dotenv').config({ path: path.join(ROOT, '.env') }); } catch (e) { /* dotenv 未安装,手动解析 */ }
  try {
    const raw = fs.readFileSync(path.join(ROOT, '.env'), 'utf8');
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) {
        let v = m[2].trim();
        if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
        process.env[m[1]] = v;
      }
    }
  } catch (e) { /* 无 .env 时静默 */ }
}
loadEnv();

const DB_CONFIG = {
  host: process.env.MYSQL_HOST || '127.0.0.1',
  port: Number(process.env.MYSQL_PORT || 3306),
  user: process.env.MYSQL_USER || 'root',
  password: process.env.MYSQL_PASSWORD || '',
  database: process.env.MYSQL_DB || '',
  waitForConnections: true,
  connectionLimit: 5,
  charset: 'utf8mb4',
  decimalNumbers: true,
};

// ---- 数据库连接池 ----
const pool = mysql.createPool(DB_CONFIG);

// ---- 允许访问的 pc_ 表 ----
const TABLES = new Set([
  'pc_projects', 'pc_tracks', 'pc_quotes', 'pc_channels',
  'pc_assets', 'pc_tasks', 'pc_feed', 'pc_blockers', 'pc_intel',
]);

// ---- 列白名单缓存 ----
const colCache = new Map();
async function tableColumns(table) {
  if (colCache.has(table)) return colCache.get(table);
  const [cols] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION`,
    [table]
  );
  const names = cols.map(c => c.COLUMN_NAME);
  colCache.set(table, names);
  return names;
}

// ---- 通用查询(带过滤,仅允许真实列) ----
async function listRows(table, filters = {}) {
  const cols = await tableColumns(table);
  const where = [];
  const params = [];
  for (const [k, v] of Object.entries(filters)) {
    if (v === undefined || v === null || v === '') continue;
    if (cols.includes(k)) { where.push(`\`${k}\` = ?`); params.push(v); }
  }
  const whereSql = where.length ? ' WHERE ' + where.join(' AND ') : '';
  const [rows] = await pool.query(`SELECT * FROM \`${table}\`${whereSql} ORDER BY id DESC LIMIT 500`, params);
  return rows;
}

async function getRow(table, id) {
  const [rows] = await pool.query(`SELECT * FROM \`${table}\` WHERE id = ? LIMIT 1`, [id]);
  return rows[0] || null;
}

async function insertRow(table, body) {
  const cols = await tableColumns(table);
  const keys = cols.filter(c => c !== 'id' && body[c] !== undefined);
  if (!keys.length) throw new Error('no valid fields');
  const placeholders = keys.map(() => '?').join(',');
  const sql = `INSERT INTO \`${table}\` (\`${keys.join('`,`')}\`) VALUES (${placeholders})`;
  const [result] = await pool.query(sql, keys.map(k => body[k]));
  const id = result.insertId;
  return getRow(table, id);
}

async function updateRow(table, id, body) {
  const cols = await tableColumns(table);
  const keys = cols.filter(c => c !== 'id' && c !== 'created_at' && c !== 'updated_at' && body[c] !== undefined);
  if (!keys.length) return getRow(table, id);
  keys.push('updated_at');
  const sets = keys.map(k => `\`${k}\` = ?`).join(',');
  const params = keys.map(k => k === 'updated_at' ? new Date() : body[k]);
  await pool.query(`UPDATE \`${table}\` SET ${sets} WHERE id = ?`, [...params, id]);
  return getRow(table, id);
}

async function deleteRow(table, id) {
  await pool.query(`DELETE FROM \`${table}\` WHERE id = ?`, [id]);
  return { ok: true, id };
}

// ============================================================
// 业务聚合查询(为四大板块提供数据)
// ============================================================

// 首页统计:各板块数据量
async function getStats() {
  const [rows] = await pool.query(`
    SELECT
      (SELECT COUNT(*) FROM pc_projects WHERE cat='server') + (SELECT COUNT(*) FROM pc_tracks WHERE project_id IN (SELECT id FROM pc_projects WHERE cat='server')) AS server_items,
      (SELECT COUNT(*) FROM pc_projects WHERE cat='llm')   + (SELECT COUNT(*) FROM pc_tracks WHERE project_id IN (SELECT id FROM pc_projects WHERE cat='llm'))   AS model_items,
      (SELECT COUNT(*) FROM pc_channels) AS channel_items,
      (SELECT COUNT(*) FROM pc_intel)    AS intel_items
  `);
  return rows[0];
}

// 大模型采购:项目 + 比价线 + 报价(按资产聚合)
async function getModelBoard() {
  const [projects] = await pool.query(`SELECT * FROM pc_projects WHERE cat='llm' ORDER BY id`);
  const board = [];
  for (const p of projects) {
    const [tracks] = await pool.query(`SELECT * FROM pc_tracks WHERE project_id=? ORDER BY id`, [p.id]);
    const [quotes] = await pool.query(`SELECT * FROM pc_quotes WHERE project_id=? AND cat='llm' ORDER BY FIELD(is_coef,1,0), price ASC`, [p.id]);
    const [assets] = await pool.query(`SELECT * FROM pc_assets WHERE cat='llm' AND q>0 ORDER BY q DESC`);
    board.push({ project: p, tracks, quotes, assets });
  }
  return board;
}

// 服务器采购:项目 + 购买/租赁/部署子线 + 报价
async function getServerBoard() {
  const [projects] = await pool.query(`SELECT * FROM pc_projects WHERE cat='server' ORDER BY id`);
  const board = [];
  for (const p of projects) {
    const [tracks] = await pool.query(`SELECT * FROM pc_tracks WHERE project_id=? ORDER BY FIELD(\`key\`,'buy','lease','deploy'), id`, [p.id]);
    const [quotes] = await pool.query(`SELECT * FROM pc_quotes WHERE project_id=? AND cat='server' ORDER BY FIELD(type,'现货','期货','租赁'), price ASC`, [p.id]);
    const [assets] = await pool.query(`SELECT * FROM pc_assets WHERE cat='server' AND q>0 ORDER BY q DESC`);
    board.push({ project: p, tracks, quotes, assets });
  }
  return board;
}

// 供应商资源库:渠道台账
async function getChannels() {
  const [rows] = await pool.query(`SELECT * FROM pc_channels ORDER BY FIELD(status_lv,'red','warn','green'), rating DESC, id`);
  return rows;
}

// 市场前沿:情报 + 任务 + 动态(供工作台)
async function getIntel() {
  const [rows] = await pool.query(`SELECT * FROM pc_intel ORDER BY FIELD(imp,'高','中','低'), id DESC`);
  return rows;
}

async function getTasks() {
  const [rows] = await pool.query(`SELECT * FROM pc_tasks ORDER BY FIELD(pri,'p0','p1'), id DESC`);
  return rows;
}

async function getFeed() {
  const [rows] = await pool.query(`SELECT * FROM pc_feed ORDER BY id DESC LIMIT 20`);
  return rows;
}

async function getBlockers() {
  const [rows] = await pool.query(`SELECT * FROM pc_blockers ORDER BY FIELD(lv,'p0','p1'), id`);
  return rows;
}

async function bootstrap() {
  const [stats, modelBoard, serverBoard, channels, intel, tasks, feed, blockers] = await Promise.all([
    getStats(), getModelBoard(), getServerBoard(), getChannels(), getIntel(), getTasks(), getFeed(), getBlockers(),
  ]);
  return { stats, modelBoard, serverBoard, channels, intel, tasks, feed, blockers };
}

// ============================================================
// HTTP 服务
// ============================================================
function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', c => { raw += c; if (raw.length > 5e6) { reject(new Error('body too large')); req.destroy(); } });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function serveStatic(req, res, urlPath) {
  let p = decodeURIComponent(urlPath.split('?')[0]);
  if (p === '/') p = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, p));
  if (!filePath.startsWith(PUBLIC_DIR)) { res.writeHead(403); res.end('Forbidden'); return; }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (p.endsWith('.html') || !path.extname(p)) {
        fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (e2, d2) => {
          if (e2) { res.writeHead(404); res.end('Not found'); }
          else { res.writeHead(200, { 'Content-Type': MIME['.html'] }); res.end(d2); }
        });
      } else { res.writeHead(404); res.end('Not found'); }
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const p = url.pathname;
  const method = req.method.toUpperCase();

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  try {
    if (p.startsWith('/api/')) {
      // 业务聚合
      if (p === '/api/bootstrap' && method === 'GET') return sendJSON(res, 200, await bootstrap());
      if (p === '/api/model-board' && method === 'GET') return sendJSON(res, 200, await getModelBoard());
      if (p === '/api/server-board' && method === 'GET') return sendJSON(res, 200, await getServerBoard());
      if (p === '/api/channels' && method === 'GET') return sendJSON(res, 200, await getChannels());
      if (p === '/api/intel' && method === 'GET') return sendJSON(res, 200, await getIntel());
      if (p === '/api/tasks' && method === 'GET') return sendJSON(res, 200, await getTasks());
      if (p === '/api/feed' && method === 'GET') return sendJSON(res, 200, await getFeed());
      if (p === '/api/blockers' && method === 'GET') return sendJSON(res, 200, await getBlockers());

      // 通用 CRUD(pc_ 表)
      const parts = p.replace('/api/', '').split('/');
      const table = parts[0];
      const id = parts[1];
      if (TABLES.has(table)) {
        if (method === 'GET' && id === undefined) {
          const filters = {};
          for (const [k, v] of url.searchParams.entries()) filters[k] = v;
          return sendJSON(res, 200, await listRows(table, filters));
        }
        if (method === 'GET' && id !== undefined) {
          const row = await getRow(table, id);
          return row ? sendJSON(res, 200, row) : sendJSON(res, 404, { error: 'not found' });
        }
        if (method === 'POST' && id === undefined) {
          return sendJSON(res, 201, await insertRow(table, await readBody(req)));
        }
        if (method === 'PUT' && id !== undefined) {
          const row = await getRow(table, id);
          if (!row) return sendJSON(res, 404, { error: 'not found' });
          return sendJSON(res, 200, await updateRow(table, id, await readBody(req)));
        }
        if (method === 'DELETE' && id !== undefined) {
          return sendJSON(res, 200, await deleteRow(table, id));
        }
        return sendJSON(res, 405, { error: 'method not allowed' });
      }
      return sendJSON(res, 404, { error: 'unknown endpoint: ' + p });
    }
    return serveStatic(req, res, p);
  } catch (e) {
    console.error('[api error]', e.message);
    return sendJSON(res, 500, { error: String(e && e.message || e) });
  }
});

server.listen(PORT, () => {
  console.log(`\n  先锋中心 · 采购资源中枢(MySQL 版)`);
  console.log(`  → http://localhost:${PORT}`);
  console.log(`  → MySQL: ${DB_CONFIG.host}/${DB_CONFIG.database}\n`);
});
