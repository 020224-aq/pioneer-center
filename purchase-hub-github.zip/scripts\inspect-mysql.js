// 只读脚本:查看 MySQL 库中已有表(了解命名规范,不写入)
const mysql = require('mysql2/promise');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.MYSQL_HOST || 'your-mysql-host.example.com',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'YOUR_DB_USER',
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DB || 'YOUR_DATABASE',
  });
  const [tables] = await conn.query(
    `SELECT TABLE_NAME, TABLE_COMMENT, TABLE_ROWS
     FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE()
     ORDER BY TABLE_NAME`
  );
  console.log('=== 当前库中的表(' + tables.length + ') ===');
  for (const t of tables) {
    console.log(`- ${t.TABLE_NAME}  (rows≈${t.TABLE_ROWS})  ${t.TABLE_COMMENT || ''}`);
  }
  await conn.end();
})().catch(e => { console.error('ERR:', e.message); process.exit(1); });
