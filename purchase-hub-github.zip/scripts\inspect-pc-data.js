// 只读:查看 pc_ 核心表数据样本(各取若干行)
// 密码通过命令行参数传入,避免 env 转义问题
const mysql = require('mysql2/promise');

(async () => {
  const password = process.argv[2];
  const conn = await mysql.createConnection({
    host: process.env.MYSQL_HOST || 'your-mysql-host.example.com',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'YOUR_DB_USER',
    password,
    database: process.env.MYSQL_DB || 'YOUR_DATABASE',
  });
  console.log('连接成功');
  const tables = ['pc_projects', 'pc_tracks', 'pc_quotes', 'pc_channels', 'pc_assets', 'pc_tasks', 'pc_feed', 'pc_blockers'];
  for (const t of tables) {
    const [rows] = await conn.query(`SELECT * FROM ${t} LIMIT 4`);
    console.log(`\n════════ ${t} (${rows.length} 行样本) ════════`);
    for (const r of rows) {
      console.log(JSON.stringify(r, (k, v) => v === null ? undefined : v));
    }
  }
  await conn.end();
})().catch(e => { console.error('ERR:', e.message); process.exit(1); });
