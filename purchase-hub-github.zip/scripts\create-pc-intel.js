// 建表:pc_intel 市场前沿情报(对齐 pc_ 原型风格)
// 用法:node scripts/create-pc-intel.js '密码'
const mysql = require('mysql2/promise');

(async () => {
  const password = process.argv[2] || '';
  const conn = await mysql.createConnection({
    host: process.env.MYSQL_HOST || 'your-mysql-host.example.com',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'YOUR_DB_USER',
    password,
    database: process.env.MYSQL_DB || 'YOUR_DATABASE',
  });

  // 先检查是否已存在
  const [exist] = await conn.query(
    `SELECT COUNT(*) AS c FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pc_intel'`
  );
  if (exist[0].c > 0) {
    console.log('pc_intel 已存在,跳过建表');
    const [cols] = await conn.query(
      `SELECT COLUMN_NAME, COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pc_intel' ORDER BY ORDINAL_POSITION`);
    console.log(cols.map(c => `${c.COLUMN_NAME} ${c.COLUMN_TYPE}`).join('\n'));
    await conn.end();
    return;
  }

  await conn.query(`
    CREATE TABLE pc_intel (
      id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      cat         VARCHAR(32)  NOT NULL COMMENT '分类:芯片路标/行业动态/调研报告/模型动态/政策',
      title       VARCHAR(255) NOT NULL COMMENT '标题',
      src         VARCHAR(128)          COMMENT '来源',
      url         VARCHAR(255)          COMMENT '链接',
      summary     TEXT                  COMMENT '摘要',
      tags        VARCHAR(255)          COMMENT '标签(逗号分隔)',
      date        VARCHAR(16)           COMMENT '发布日期,如 9/5',
      imp         VARCHAR(8)            COMMENT '重要度:高/中/低',
      status      VARCHAR(16)  DEFAULT '待阅' COMMENT '状态:待阅/已阅/已归档',
      owner       VARCHAR(64)           COMMENT '负责人',
      created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY idx_cat (cat),
      KEY idx_imp (imp)
    ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '市场前沿情报(采购资源中枢·板块四)'
  `);
  console.log('✅ pc_intel 表创建成功');
  await conn.end();
})().catch(e => { console.error('ERR:', e.message); process.exit(1); });
