// A2 数据入库脚本 2：补全大模型系数报价 + 修正错误数据
const mysql = require('mysql2/promise');

const conf = {
  host: 'your-mysql-host.example.com', port: 3306,
  user: 'YOUR_DB_USER', password: process.env.DB_PASS || '' + (process.env.MYSQL_PASSWORD || '') + '',
  database: 'YOUR_DATABASE', charset: 'utf8mb4',
};

async function upsert(conn, row) {
  const cols = Object.keys(row);
  const placeholders = cols.map(() => '?').join(',');
  const upd = cols.map(c => `${c}=VALUES(${c})`).join(',');
  const sql = `INSERT INTO pc_quotes (${cols.map(c => '`' + c + '`').join(',')}) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${upd}`;
  try { await conn.query(sql, cols.map(c => row[c])); return 'ok'; }
  catch (e) { return 'ERR: ' + e.message; }
}

async function main() {
  const conn = await mysql.createConnection(conf);
  console.log('✅ 连接成功');

  // ============ 1. 修正火山 Pro 系数错误 0.8 → 1.86 ============
  await conn.query("UPDATE pc_quotes SET price=1.86, cond='已获取首轮正式报价，无保底消耗，有TMP技术支持' WHERE id='q29'");
  console.log('✅ 修正 q29 火山 V4-Pro 系数 0.8 → 1.86');

  // ============ 2. 补全大模型系数报价 ============
  const llmQuotes = [
    // Pro 模型系数（ds-v4 pro 0813）
    { id: 'q41', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'V4-Pro', asset_name: 'ds-v4 pro 0813', channel: '官方基准', channel_id: null, type: '官方价', price: 3.0, unit: '系数', cond: 'DS官方基准系数', quote_date: '9/7', is_coef: 1, lowest: 0 },
    { id: 'q42', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'V4-Pro', asset_name: 'ds-v4 pro 0813', channel: '腾讯云', channel_id: 'c15', type: '官方价', price: 1.8, unit: '系数', cond: '已确认合作，待接入', quote_date: '9/7', is_coef: 1, lowest: 1 },
    { id: 'q43', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'V4-Pro', asset_name: 'ds-v4 pro 0813', channel: '阿里云(2)', channel_id: 'c19', type: '官方价', price: 2.66, unit: '系数', cond: '首轮正式报价', quote_date: '9/7', is_coef: 1, lowest: 0 },
    { id: 'q44', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'V4-Pro', asset_name: 'ds-v4 pro 0813', channel: '阿里云(1)', channel_id: 'c18', type: '官方价', price: 3.15, unit: '系数', cond: '对比官方更贵，暂不推进', quote_date: '9/7', is_coef: 1, lowest: 0 },
    { id: 'q45', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'V4-Pro', asset_name: 'ds-v4 pro 0813', channel: '京东云', channel_id: 'c17', type: '官方价', price: 3.8, unit: '系数', cond: '9/8线上沟通', quote_date: '9/7', is_coef: 1, lowest: 0 },
    { id: 'q46', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'V4-Pro', asset_name: 'ds-v4 pro 0813', channel: '华为云', channel_id: 'c20', type: '官方价', price: 23.46, unit: '系数', cond: '初步沟通，未给优惠报价', quote_date: '9/7', is_coef: 1, lowest: 0 },
    // 其他模型
    { id: 'q47', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'Qwen3.7-plus', asset_name: 'Qwen3.7-plus', channel: '京东云', channel_id: 'c17', type: '官方价', price: 0.75, unit: '系数', cond: '可调，一年起签', quote_date: '9/7', is_coef: 1, lowest: 0 },
    { id: 'q48', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'glm-5.3-flash', asset_name: 'glm-5.3-flash', channel: '七牛云', channel_id: null, type: '官方价', price: 0.46, unit: '系数', cond: '同比官方节省45%，主供应商推进', quote_date: '9/7', is_coef: 1, lowest: 1 },
    { id: 'q49', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'Kimi-K3', asset_name: 'Kimi-K3', channel: '京东云', channel_id: 'c17', type: '官方价', price: 0.84, unit: '系数', cond: '9/8确认合作', quote_date: '9/7', is_coef: 1, lowest: 0 },
    { id: 'q50', project_id: 'p2', track: 'llm', cat: 'llm', asset: 'MiniMax-M3', asset_name: 'MiniMax-M3', channel: '待确认', channel_id: null, type: '官方价', price: 0.84, unit: '系数', cond: '待确认', quote_date: '9/7', is_coef: 1, lowest: 0 },
  ];

  let ok = 0, err = 0;
  for (const q of llmQuotes) {
    const r = await upsert(conn, q);
    if (r === 'ok') ok++; else { err++; console.log('  失败:', q.asset, r); }
  }
  console.log(`大模型系数报价: 新增 ${ok} 条` + (err ? `，失败 ${err}` : ''));

  // ============ 3. 补充七牛云渠道 ============
  await conn.query(`INSERT INTO pc_channels (id,name,kind,type_code,status,status_lv,rating,note) VALUES ('c34','七牛云','厂商','vendor','已核验','ok',4,'glm模型同比官方节省较多') ON DUPLICATE KEY UPDATE name=VALUES(name)`);
  console.log('✅ 补充七牛云渠道');

  await conn.end();
  console.log('\n✅ 大模型数据入库完成');
}
main().catch(e => { console.error('❌', e.message); process.exit(1); });
