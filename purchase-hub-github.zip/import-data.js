// A2 数据入库脚本：补齐飞书文档里的服务器渠道 + 报价 + 大模型系数
const mysql = require('mysql2/promise');

const conf = {
  host: 'your-mysql-host.example.com', port: 3306,
  user: 'YOUR_DB_USER', password: process.env.DB_PASS || '' + (process.env.MYSQL_PASSWORD || '') + '',
  database: 'YOUR_DATABASE', charset: 'utf8mb4',
};

// 渠道类型映射（kind 中文 → type_code）
const KIND_MAP = { '中介': 'broker', '厂商': 'vendor', '企业直采': 'direct', '直销': 'direct', '企业': 'direct', '组装厂': 'oem', '托管商': 'dc', '工程队': 'eng', '直签': 'direct', '华为官方': 'vendor' };

async function upsert(conn, table, row, pkCol = 'id') {
  const cols = Object.keys(row);
  const placeholders = cols.map(() => '?').join(',');
  const upd = cols.map(c => `${c}=VALUES(${c})`).join(',');
  const sql = `INSERT INTO ${table} (${cols.map(c => '`' + c + '`').join(',')}) VALUES (${placeholders}) ON DUPLICATE KEY UPDATE ${upd}`;
  try { await conn.query(sql, cols.map(c => row[c])); return 'ok'; }
  catch (e) { return 'ERR: ' + e.message; }
}

async function main() {
  const conn = await mysql.createConnection(conf);
  console.log('✅ 连接成功');

  // ============ 1. 新增渠道 ============
  const newChannels = [
    { id: 'c21', name: '北京天弛网络', kind: '中介', type_code: 'broker', status: '已核验', status_lv: 'ok', rating: 4, note: '注册资本2100万，成立2012-05-16，同泰怡8卡H200现货475万5台成都现货' },
    { id: 'c22', name: '上海锦爵', kind: '企业直采', type_code: 'direct', status: '已核验', status_lv: 'ok', rating: 4, note: '注册2009年，注册资本500万，图形工作站372.6万，交付7天维保3年，PCIE版' },
    { id: 'c23', name: '联创万通(北京)科技', kind: '企业直采', type_code: 'direct', status: '已核验', status_lv: 'ok', rating: 4, note: '注册资本10000万，成立2005-04-26，期货550万含税月底到货，30%定金锁货' },
    { id: 'c24', name: '杭州水泽乾天科技', kind: '中介', type_code: 'broker', status: '已核验', status_lv: 'ok', rating: 3, note: '注册资本1200万，成立2020，Dell XE9680现货550万18台，20%预付3年质保' },
    { id: 'c25', name: '中值智能', kind: '中介', type_code: 'broker', status: '需关注', status_lv: 'warn', rating: 3, note: '超微H200满配，67.5万美金现货+17万过关费+16万大小合同，深圳交货' },
    { id: 'c26', name: '深圳凯欣信息技术', kind: '直销', type_code: 'direct', status: '已核验', status_lv: 'ok', rating: 4, note: '华勤H200NVL 400万含税、超聚变H200 555万现货1台，质保三年深圳交货' },
    { id: 'c27', name: '深圳力淳科技', kind: '直签', type_code: 'direct', status: '已核验', status_lv: 'ok', rating: 4, note: 'AMD MI300X 470万，9台全新现货原厂质保三年' },
    { id: 'c28', name: '广州科探信息科技', kind: '中介', type_code: 'broker', status: '已核验', status_lv: 'ok', rating: 4, note: '超微SYS-822GS-NB3RT含税1500万' },
    { id: 'c29', name: '润建股份', kind: '工程队', type_code: 'eng', status: '待背调', status_lv: 'warn', rating: 0, note: '新增建联工程队' },
    { id: 'c30', name: '广东天耘科技', kind: '托管商', type_code: 'dc', status: '待背调', status_lv: 'warn', rating: 0, note: '广东省内托管机构，已给初步报价，IB网络报价待补充' },
    { id: 'c31', name: '中国电信', kind: '托管商', type_code: 'dc', status: '待背调', status_lv: 'warn', rating: 0, note: '广州各区电信基地/韶关，9.9前给报价单' },
    { id: 'c32', name: '中国移动', kind: '托管商', type_code: 'dc', status: '待背调', status_lv: 'warn', rating: 0, note: '广州天河智慧城，9.11前给报价单，可协助组网' },
    { id: 'c33', name: '北京金山云', kind: '托管商', type_code: 'dc', status: '待背调', status_lv: 'warn', rating: 0, note: '待确认华南机房位置，预计9.7给报价单' },
  ];
  let chOk = 0, chErr = 0;
  for (const ch of newChannels) {
    const r = await upsert(conn, 'pc_channels', ch);
    if (r === 'ok') chOk++; else { chErr++; console.log('  渠道失败:', ch.name, r); }
  }
  console.log(`渠道: 新增 ${chOk} 条` + (chErr ? `，失败 ${chErr}` : ''));

  // ============ 2. 新增服务器报价（9/7 新渠道） ============
  const newQuotes = [
    { id: 'q30', project_id: 'p1', track: 'buy', cat: 'server', asset: 'H200', asset_name: '同泰怡 8卡 H200', channel: '北京天弛网络', channel_id: 'c21', type: '现货', price: 475, unit: '万/台', cond: '5台成都现货，三年维保', quote_date: '9/7', is_coef: 0, lowest: 0 },
    { id: 'q31', project_id: 'p1', track: 'buy', cat: 'server', asset: 'H200', asset_name: '图形工作站 NJ-IJ05G8', channel: '上海锦爵', channel_id: 'c22', type: '现货', price: 372.6, unit: '万/台', cond: '交付周期7天，维保3年，PCIE版', quote_date: '9/7', is_coef: 0, lowest: 1 },
    { id: 'q32', project_id: 'p1', track: 'buy', cat: 'server', asset: 'H200', asset_name: 'H200', channel: '联创万通(北京)科技', channel_id: 'c23', type: '期货', price: 550, unit: '万/台', cond: '含税月底到货，30%定金锁货', quote_date: '9/7', is_coef: 0, lowest: 0 },
    { id: 'q33', project_id: 'p1', track: 'buy', cat: 'server', asset: 'H200', asset_name: 'Dell PowerEdge XE9680', channel: '杭州水泽乾天科技', channel_id: 'c24', type: '现货', price: 550, unit: '万/台', cond: '18台，20%预付，3年质保', quote_date: '9/7', is_coef: 0, lowest: 0 },
    { id: 'q34', project_id: 'p1', track: 'buy', cat: 'server', asset: 'H200', asset_name: '华勤 H200NVL PCIE整机', channel: '深圳凯欣信息技术', channel_id: 'c26', type: '现货', price: 400, unit: '万/台', cond: '质保三年，深圳交货', quote_date: '9/7', is_coef: 0, lowest: 1 },
    { id: 'q35', project_id: 'p1', track: 'buy', cat: 'server', asset: 'H200', asset_name: '超聚变 H200', channel: '深圳凯欣信息技术', channel_id: 'c26', type: '现货', price: 555, unit: '万/台', cond: '只有一台，东莞/深圳提货', quote_date: '9/7', is_coef: 0, lowest: 0 },
    { id: 'q36', project_id: 'p1', track: 'buy', cat: 'server', asset: 'B300', asset_name: '超微 SYS-822GS-NB3RT', channel: '货主不确定', channel_id: 'c4', type: '现货', price: 1430, unit: '万/台', cond: '8U HGX B300 NVL8 SXM-8卡整机，现货64台内地交付', quote_date: '9/7', is_coef: 0, lowest: 0 },
    { id: 'q37', project_id: 'p1', track: 'buy', cat: 'server', asset: 'B300', asset_name: '戴尔 4T B300', channel: '货主不确定', channel_id: 'c4', type: '现货', price: 1455, unit: '万/台', cond: '现货128台内地交付，戴尔预计涨价', quote_date: '9/7', is_coef: 0, lowest: 0 },
    { id: 'q38', project_id: 'p1', track: 'buy', cat: 'server', asset: 'B300', asset_name: '超微 SYS-822GS-NB3RT', channel: '广州科探信息科技', channel_id: 'c28', type: '现货', price: 1500, unit: '万/台', cond: '含税，6767P*2/128G6400*32/HGX B300/CX8 800G*8', quote_date: '9/7', is_coef: 0, lowest: 0 },
    { id: 'q39', project_id: 'p1', track: 'buy', cat: 'server', asset: 'MI300X', asset_name: 'AMD MI300X', channel: '深圳力淳科技', channel_id: 'c27', type: '现货', price: 470, unit: '万/台', cond: '9台全新现货，原厂质保三年', quote_date: '9/3', is_coef: 0, lowest: 0 },
    { id: 'q40', project_id: 'p1', track: 'buy', cat: 'server', asset: '950PR', asset_name: 'Atlas 650', channel: '华为官方', channel_id: 'c20', type: '现货', price: 300, unit: '万/台', cond: '8*Ascend 950PR，14U机架式，现货先到先得', quote_date: '9/3', is_coef: 0, lowest: 0 },
  ];
  let qOk = 0, qErr = 0;
  for (const q of newQuotes) {
    const r = await upsert(conn, 'pc_quotes', q);
    if (r === 'ok') qOk++; else { qErr++; console.log('  报价失败:', q.channel, r); }
  }
  console.log(`报价: 新增 ${qOk} 条` + (qErr ? `，失败 ${qErr}` : ''));

  await conn.end();
  console.log('\n✅ 入库完成');
}
main().catch(e => { console.error('❌', e.message); process.exit(1); });
