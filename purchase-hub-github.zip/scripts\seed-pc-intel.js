// 写入 pc_intel 种子情报(基于真实业务动态)
const mysql = require('mysql2/promise');

const items = [
  { cat: '芯片路标', title: '昇腾 950 系列产品路线', src: '华为线下沟通', summary: '950 PR(推理)已在售,950 DT(训练)9 月发布/10 月上市;960 明年 Q4,970 2028 Q4;950 对标英伟达 B300,集群有优势。', tags: '华为,昇腾,国产芯片', date: '9/3', imp: '高', owner: '安琪' },
  { cat: '调研报告', title: 'GPU 服务器现货采购风险预警', src: '内部', summary: '风险规避六步:配置单→背调→合同→验货→压测→交易(现场付款自提)。', tags: '风险,采购', date: '9/4', imp: '高', owner: '安琪' },
  { cat: '模型动态', title: 'DeepSeek 官方基准价(2026-08-17 新价)', src: '内部测算', summary: '官方 Flash 单次请求成本 0.0144182 元 = 价格系数 1.0;全厂商统一口径折算。', tags: 'DeepSeek,基准价', date: '9/3', imp: '高', owner: '安琪' },
  { cat: '模型动态', title: '海外大模型中转站报价模式', src: '建联', summary: '官转最可控 > 原厂转半可控 > 号池不可控(封号风险);GLM 官转约 7 折,七牛云 6.5 折更优。', tags: '中转站,GLM', date: '9/5', imp: '中', owner: '黎雨婷' },
  { cat: '芯片路标', title: '国产海光处理器入英伟达库档', src: '采购早会', summary: '海光处理器已入英伟达库档,可布 K2/K3,需纳入服务器性能对比。', tags: '海光,国产', date: '9/4', imp: '中', owner: '黎雨婷' },
  { cat: '行业动态', title: 'B300 因海关查扣流通受限', src: '移动沟通', summary: '台湾 1.5 亿等事件致 B300 海关查扣,流通量少于 H200,B200 亦较少。', tags: 'B300,海关', date: '9/4', imp: '中', owner: '安琪' },
];

(async () => {
  const password = process.argv[2] || '';
  const conn = await mysql.createConnection({
    host: process.env.MYSQL_HOST || 'your-mysql-host.example.com',
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'YOUR_DB_USER',
    password,
    database: process.env.MYSQL_DB || 'YOUR_DATABASE',
  });
  // 检查是否已有数据
  const [rows] = await conn.query('SELECT COUNT(*) AS c FROM pc_intel');
  if (rows[0].c > 0) { console.log('pc_intel 已有 ' + rows[0].c + ' 条,跳过种子'); await conn.end(); return; }
  const ins = `INSERT INTO pc_intel (cat, title, src, url, summary, tags, date, imp, status, owner) VALUES (?,?,?,?,?,?,?,?, '待阅', ?)`;
  for (const it of items) {
    await conn.query(ins, [it.cat, it.title, it.src, '', it.summary, it.tags, it.date, it.imp, it.owner]);
  }
  console.log('✅ pc_intel 写入 ' + items.length + ' 条情报');
  await conn.end();
})().catch(e => { console.error('ERR:', e.message); process.exit(1); });
