// 替换决策动态(pc_feed) + 任务(pc_tasks) + 立项负责人(pc_projects)里的占位名 → 真实成员
const mysql = require('mysql2/promise');
const conf = {
  host: 'your-mysql-host.example.com', port: 3306,
  user: 'YOUR_DB_USER', password: process.env.DB_PASS || '' + (process.env.MYSQL_PASSWORD || '') + '',
  database: 'YOUR_DATABASE', charset: 'utf8mb4',
};

async function main() {
  const c = await mysql.createConnection(conf);
  console.log('✅ 连接成功，开始替换占位名');

  // ============ pc_feed 决策动态（按 id 精确映射） ============
  // 语义：decision=负责人结论，quote=寻源报价入库，risk=系统
  const feedMap = {
    1: '安琪',      // 服务器采购结论(最终建议负责人)
    2: '黎雨婷',    // 大模型比价结论
    3: '陈增铭',    // 天翼云 H200 报价入库(服务器寻源)
    4: '虞雯锜',    // 网宿 B300 租赁报价入库(服务器寻源)
    5: '黎雨婷',    // 腾讯云/火山 Flash 系数
    6: '陈增铭',    // H200 报价9连入(寻源)
    7: '系统',      // 风险提醒(保留系统)
    8: '何悦',      // 部署12楼勘测(部署工程)
  };
  for (const [id, name] of Object.entries(feedMap)) {
    await c.query('UPDATE pc_feed SET who=? WHERE id=?', [name, id]);
  }
  console.log('✅ pc_feed 决策动态 8 条已替换');

  // ============ pc_tasks 任务（按 id 精确映射） ============
  const taskMap = {
    1: '何悦 / 刘芸菲',   // 物业/工程队勘测
    2: '何悦',            // 第二家工程队勘测
    3: '黎雨婷',          // 腾讯云线下会议
    4: '夏牧原 / 毛友琦', // 核实货源真实性(风控)
    5: '陈增铭 / 虞雯锜', // 持续寻源
    6: '黎雨婷',          // 华为云商务折扣
    7: '黎雨婷 / 安琪',   // 确认合作主体(品牌/税务/合规)
  };
  for (const [id, who] of Object.entries(taskMap)) {
    await c.query('UPDATE pc_tasks SET who=? WHERE id=?', [who, id]);
  }
  console.log('✅ pc_tasks 任务 7 条已替换');

  // ============ pc_projects 立项负责人 ============
  await c.query("UPDATE pc_projects SET `lead`='安琪' WHERE id='p1'");   // 服务器采购
  await c.query("UPDATE pc_projects SET `lead`='黎雨婷' WHERE id='p2'"); // 大模型采购
  console.log('✅ pc_projects 立项负责人已替换');

  await c.end();
  console.log('\n✅ 全部替换完成');
}
main().catch(e => { console.error('❌', e.message); process.exit(1); });
