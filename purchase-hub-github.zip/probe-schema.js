const mysql = require('mysql2/promise');
(async () => {
  const c = await mysql.createConnection({
    host: 'your-mysql-host.example.com', port: 3306,
    user: 'YOUR_DB_USER', password: process.env.DB_PASS || '' + (process.env.MYSQL_PASSWORD || '') + '',
    database: 'YOUR_DATABASE',
  });
  const [r] = await c.query("SELECT TABLE_NAME,COLUMN_NAME,COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='YOUR_DATABASE' AND TABLE_NAME LIKE 'pc_%' ORDER BY TABLE_NAME,ORDINAL_POSITION");
  const g = {};
  r.forEach(x => { if (!g[x.TABLE_NAME]) g[x.TABLE_NAME] = []; g[x.TABLE_NAME].push(x.COLUMN_NAME + ' ' + x.COLUMN_TYPE); });
  for (const t in g) { console.log('\n[' + t + ']'); console.log('  ' + g[t].join(' | ')); }
  await c.end();
})().catch(e => console.error('ERR', e.message));
