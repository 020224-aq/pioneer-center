/* ═══════════════════════════════════════════════════════════
   大模型业务系统 · UI 原型脚本
   滚动联动 / 模型目录三级页 / 横向日志轴 / 测算计算器 / 规则抽屉
   ═══════════════════════════════════════════════════════════ */
'use strict';

/* ---------- 工具 ---------- */
const $  = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
const fmt = (n, d = 0) => Number(n).toLocaleString('zh-CN', { minimumFractionDigits: d, maximumFractionDigits: d });
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function toast(msg) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.innerHTML = `<span>${msg}</span>`;
  $('#toasts').appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, 2200);
}

/* ---------- 日期 ---------- */
const NOW = new Date(2026, 8, 5); // 2026-09-05 周六(演示基准日)
$('#todayStr').textContent = `${NOW.getFullYear()}.${String(NOW.getMonth() + 1).padStart(2, '0')}.${String(NOW.getDate()).padStart(2, '0')} ${['周日','周一','周二','周三','周四','周五','周六'][NOW.getDay()]}`;

/* ═══════════════════════════════════════════════
   顶部导航 · 滚动联动
   ═══════════════════════════════════════════════ */
const sections = $$('.sec');
const segBtns  = $$('.seg-btn');
const segThumb = $('.seg-thumb');

function setSeg(i) {
  segBtns.forEach((b, idx) => b.classList.toggle('is-active', idx === i));
  segThumb.style.transform = `translateX(${i * 100}%)`;
}

function segScroll(i) {
  const y = sections[i].getBoundingClientRect().top + window.scrollY - 12;
  window.scrollTo({ top: y, behavior: 'smooth' });
}

segBtns.forEach((b, i) => b.addEventListener('click', () => segScroll(i)));

/* 滚动监听:手动滚动时高亮当前板块(容器整体就是页面滚动) */
let ticking = false;
function onScroll() {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(() => {
    const mid = window.innerHeight * 0.4;
    let cur = 0;
    sections.forEach((s, i) => {
      const r = s.getBoundingClientRect();
      if (r.top <= mid) cur = i;
    });
    setSeg(cur);
    ticking = false;
  });
}
window.addEventListener('scroll', onScroll, { passive: true });

/* ═══════════════════════════════════════════════
   数据
   ═══════════════════════════════════════════════ */
const SERIES = [
  { id: 'qwen',   name: '千问',     ico: '千', desc: '通义千问系列,阿里云出品,覆盖端侧到旗舰通用与推理模型。' },
  { id: 'doubao', name: '豆包',     ico: '豆', desc: '字节跳动自研系列,主打高性价比与多模态能力。' },
  { id: 'wenxin', name: '文心',     ico: '文', desc: '百度文心系列,深耕中文语义理解与行业知识增强。' },
  { id: 'hunyuan',name: '混元',     ico: '混', desc: '腾讯混元系列,兼顾通用对话与企业级场景。' },
  { id: 'deepseek',name: 'DeepSeek',ico: 'D', desc: '深度求索系列,以开源与推理能力见长,价格竞争力强。' },
  { id: 'gpt',    name: 'GPT',      ico: 'G', desc: 'OpenAI 旗舰系列,多模态与复杂推理标杆。' },
  { id: 'claude', name: 'Claude',   ico: 'C', desc: 'Anthropic 出品,长上下文与代码能力突出。' },
  { id: 'glm',    name: '智谱 GLM', ico: '智', desc: '智谱AI 自研系列,覆盖开源与商业模型。' },
];

const MODELS = [
  /* 千问 */
  { id: 'q1', series: 'qwen',    name: 'Qwen3-Max',   tag: '旗舰', desc: '千问系列最强通用模型,复杂指令遵循与多步推理表现突出,适合高价值业务场景。', market: '国内综合能力第一梯队,长期霸榜中文场景基准。', firm: '某云科技', firmIco: '云', offIn: 2.4, offOut: 9.6, parIn: 1.68, parOut: 6.72, savePct: 30, docs: 3, usage: 'qwen' },
  { id: 'q2', series: 'qwen',    name: 'Qwen3-235B',  tag: '最新', desc: '大规模 MoE 稠密混合架构,千问系列最新开源旗舰。', market: '开源阵营最强之一,推理成本约为同类三分之一。', firm: '某云科技', firmIco: '云', offIn: 1.2, offOut: 4.8, parIn: 0.84, parOut: 3.36, savePct: 30, docs: 2, usage: 'qwen' },
  { id: 'q3', series: 'qwen',    name: 'Qwen2.5-72B', desc: '千问 2.5 时代的中大规模模型,平衡效果与成本。', market: '中小规模部署的主流选择之一。', firm: '某云科技', firmIco: '云', offIn: 1.0, offOut: 4.0, parIn: 0.7, parOut: 2.8, savePct: 30, docs: 2, usage: 'qwen' },
  { id: 'q4', series: 'qwen',    name: 'Qwen3-32B',   tag: '热门', desc: '32B 级高效模型,支持长文本与工具调用。', market: '开源 32B 档位的热门选择。', firm: '某云科技', firmIco: '云', offIn: 0.72, offOut: 2.4, parIn: 0.5, parOut: 1.68, savePct: 30, docs: 2, usage: 'qwen' },
  /* 豆包 */
  { id: 'd1', series: 'doubao',  name: 'Doubao-1.5-Pro', tag: '热门', desc: '豆包旗舰 Pro 版,综合能力与价格平衡出色。', market: '性价比标杆,百万级 Tokens 价格极具竞争力。', firm: '某互动科技', firmIco: '互', offIn: 0.8, offOut: 2.0, parIn: 0.52, parOut: 1.3, savePct: 35, docs: 3, usage: 'doubao' },
  { id: 'd2', series: 'doubao',  name: 'Doubao-1.5-lite', desc: '轻量版模型,适合高并发低延迟场景。', market: '低价档代表,量大管饱。', firm: '某互动科技', firmIco: '互', offIn: 0.3, offOut: 0.6, parIn: 0.2, parOut: 0.4, savePct: 35, docs: 1, usage: 'doubao' },
  { id: 'd3', series: 'doubao',  name: 'Doubao-Seed-1.6', tag: '最新', desc: 'Seed 系列最新版本,多模态理解能力增强。', market: '多模态评测的新锐黑马。', firm: '某互动科技', firmIco: '互', offIn: 0.9, offOut: 2.4, parIn: 0.59, parOut: 1.56, savePct: 35, docs: 2, usage: 'doubao' },
  /* 文心 */
  { id: 'w1', series: 'wenxin',  name: 'ERNIE-4.5-Turbo', tag: '热门', desc: '文心四代 Turbo,中文场景与知识问答能力扎实。', market: '中文理解与生成的传统强队。', firm: '某云智算', firmIco: '云', offIn: 0.8, offOut: 2.0, parIn: 0.56, parOut: 1.4, savePct: 30, docs: 2, usage: 'wenxin' },
  { id: 'w2', series: 'wenxin',  name: 'ERNIE-4.0',   desc: '文心 4.0 旗舰,复杂任务理解与创作。', market: '企业级中文场景的常用选择。', firm: '某云智算', firmIco: '云', offIn: 1.2, offOut: 4.0, parIn: 0.84, parOut: 2.8, savePct: 30, docs: 2, usage: 'wenxin' },
  { id: 'w3', series: 'wenxin',  name: 'ERNIE-Speed', desc: '极速低价版,适合轻量交互。', market: '高频低成本的典型代表。', firm: '某云智算', firmIco: '云', offIn: 0.2, offOut: 0.4, parIn: 0.14, parOut: 0.28, savePct: 30, docs: 1, usage: 'wenxin' },
  /* 混元 */
  { id: 'h1', series: 'hunyuan', name: 'Hunyuan-T1',  tag: '旗舰', desc: '腾讯混元思考模型,推理链路完整。', market: '推理模型领域的有力竞争者。', firm: '某数科公司', firmIco: '数', offIn: 1.0, offOut: 4.0, parIn: 0.7, parOut: 2.8, savePct: 30, docs: 2, usage: 'hunyuan' },
  { id: 'h2', series: 'hunyuan', name: 'Hunyuan-Turbo', desc: '混元加速版,低延迟优化。', market: '实时交互场景的优选。', firm: '某数科公司', firmIco: '数', offIn: 0.6, offOut: 1.8, parIn: 0.42, parOut: 1.26, savePct: 30, docs: 2, usage: 'hunyuan' },
  { id: 'h3', series: 'hunyuan', name: 'Hunyuan-Lite', desc: '轻量免费档起步,适合试探性接入。', market: '门槛最低的接入选项之一。', firm: '某数科公司', firmIco: '数', offIn: 0.1, offOut: 0.2, parIn: 0.07, parOut: 0.14, savePct: 30, docs: 1, usage: 'hunyuan' },
  /* DeepSeek */
  { id: 's1', series: 'deepseek',name: 'DeepSeek-V4', tag: '热门', desc: 'DeepSeek 新一代旗舰,推理与代码能力大幅提升,价格维持行业低位。', market: '当前公司主力采购模型,性价比第一梯队。', firm: '杭州深度求索', firmIco: 'D', offIn: 1.0, offOut: 4.0, parIn: 0.62, parOut: 2.5, savePct: 38, docs: 3, usage: 'deepseek' },
  { id: 's2', series: 'deepseek',name: 'DeepSeek-V3.2', desc: '上一代旗舰,稳定可靠,仍服务大量存量业务。', market: '存量业务的稳定主力。', firm: '杭州深度求索', firmIco: 'D', offIn: 1.0, offOut: 4.0, parIn: 0.62, parOut: 2.5, savePct: 38, docs: 2, usage: 'deepseek' },
  { id: 's3', series: 'deepseek',name: 'DeepSeek-R2', tag: '最新', desc: '专注深度推理的思考模型,数学与代码场景强化。', market: '推理专项场景的头部选择。', firm: '杭州深度求索', firmIco: 'D', offIn: 2.0, offOut: 8.0, parIn: 1.24, parOut: 4.96, savePct: 38, docs: 2, usage: 'deepseek' },
  /* GPT */
  { id: 'g1', series: 'gpt',     name: 'GPT-5',       tag: '旗舰', desc: 'OpenAI 最新旗舰,多模态推理与 Agent 能力全面升级。', market: '全球通用能力标杆。', firm: '某出海云服务', firmIco: 'G', offIn: 16, offOut: 64, parIn: 13.6, parOut: 54.4, savePct: 15, docs: 2, usage: 'gpt' },
  { id: 'g2', series: 'gpt',     name: 'GPT-5-mini',  desc: 'GPT-5 的高性价比轻量版。', market: '海外高频场景的平衡之选。', firm: '某出海云服务', firmIco: 'G', offIn: 4, offOut: 16, parIn: 3.4, parOut: 13.6, savePct: 15, docs: 2, usage: 'gpt' },
  { id: 'g3', series: 'gpt',     name: 'o3',          tag: '热门', desc: '深度推理系列,复杂科学问题表现优异。', market: '复杂推理的海外主力。', firm: '某出海云服务', firmIco: 'G', offIn: 10, offOut: 40, parIn: 8.5, parOut: 34, savePct: 15, docs: 1, usage: 'gpt' },
  /* Claude */
  { id: 'c1', series: 'claude',  name: 'Claude Opus 4.5', tag: '旗舰', desc: 'Anthropic 最强模型,长上下文与代码能力业界顶尖。', market: '代码与长文写作的行业标杆。', firm: '某出海云服务', firmIco: 'C', offIn: 25, offOut: 125, parIn: 21.25, parOut: 106.25, savePct: 15, docs: 2, usage: 'claude' },
  { id: 'c2', series: 'claude',  name: 'Claude Sonnet 4.5', tag: '热门', desc: '性能/价格平衡旗舰,广泛用于生产环境。', market: '海外生产负载最常见的接入模型。', firm: '某出海云服务', firmIco: 'C', offIn: 5, offOut: 25, parIn: 4.25, parOut: 21.25, savePct: 15, docs: 2, usage: 'claude' },
  { id: 'c3', series: 'claude',  name: 'Claude Haiku 4.5', desc: '极速轻量版,适合大规模低延迟调用。', market: '海外高并发场景的成本优选。', firm: '某出海云服务', firmIco: 'C', offIn: 1, offOut: 5, parIn: 0.85, parOut: 4.25, savePct: 15, docs: 1, usage: 'claude' },
  /* 智谱 */
  { id: 'z1', series: 'glm',     name: 'GLM-5',       tag: '最新', desc: '智谱最新旗舰,Agent 能力与中文场景优化。', market: '国产第一梯队的有力竞争者。', firm: '某智算云', firmIco: '智', offIn: 1.0, offOut: 4.0, parIn: 0.7, parOut: 2.8, savePct: 30, docs: 2, usage: 'glm' },
  { id: 'z2', series: 'glm',     name: 'GLM-4.7-Plus', desc: '上代旗舰,生产环境验证充分。', market: '稳定可靠的企业接入方案。', firm: '某智算云', firmIco: '智', offIn: 0.6, offOut: 2.4, parIn: 0.42, parOut: 1.68, savePct: 30, docs: 1, usage: 'glm' },
];

const bySeries = id => MODELS.filter(m => m.series === id);

/* 报价文档(按模型系列+版本生成) */
const DOC_TEMPLATES = [
  { name: '报价单', date: '2026.08.28', src: '合作商' },
  { name: '报价复核纪要', date: '2026.09.01', src: '商务组' },
  { name: '阶梯价补充协议', date: '2026.09.04', src: '法务' },
];
function docsFor(m, n) {
  return DOC_TEMPLATES.slice(0, n).map((d, i) => ({
    name: `${m.name}${d.name}${i === 0 ? '' : '·' + (i + 1)}`,
    date: d.date,
    src: d.src,
  }));
}

/* 使用量序列(按模型生成确定性伪数据) */
function usageFor(m) {
  let seed = 0;
  for (const ch of m.id) seed = (seed * 31 + ch.charCodeAt(0)) % 100000;
  const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  const days = 30;
  const calls = [], toks = [];
  const base = 40000 + rnd() * 160000, baseT = 900 + rnd() * 2600;
  for (let i = 0; i < days; i++) {
    const w = 0.55 + 0.45 * Math.sin(i / 6.2) + rnd() * 0.3;
    calls.push(Math.round(base * w));
    toks.push(Math.round(baseT * w));
  }
  const users = Math.round(1200 + rnd() * 2200);
  return { calls, toks, users, days };
}

/* ═══════════════════════════════════════════════
   板块一 · 视图路由(landing / series / detail)
   ═══════════════════════════════════════════════ */
const VIEWS = { landing: $('#view-landing'), series: $('#view-series'), detail: $('#view-detail') };
let curModelId = null;

function showView(name) {
  Object.entries(VIEWS).forEach(([k, v]) => v.classList.toggle('is-active', k === name));
  /* 详情页为全屏覆盖层:打开时锁定 body 滚动并归顶,关闭时解锁 */
  if (name === 'detail') {
    document.body.classList.add('lock-detail');
    const sc = $('#detailScroll');
    if (sc) sc.scrollTop = 0;
  } else {
    document.body.classList.remove('lock-detail');
  }
}

/* 入口卡片 → 二级 */
$('#heroBtn').addEventListener('click', () => showView('series'));
$('#heroBtn').addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); showView('series'); } });

/* 返回 */
$$('.back').forEach(b => b.addEventListener('click', () => {
  const target = b.dataset.go;
  if (target === 'landing') showView('landing');
  else if (target === 'series') showView('series');
}));

/* 渲染系列列表 + 版本网格 */
function renderSeries() {
  const list = $('#seriesList');
  const total = SERIES.reduce((a, s) => a + bySeries(s.id).length, 0);
  $('#seriesTotal').textContent = `${total} 个版本`;
  list.innerHTML = SERIES.map(s => {
    const c = bySeries(s.id).length;
    return `<li class="s-item" data-id="${s.id}"><span class="ico">${s.ico}</span><span>${s.name}</span><span class="s-count">${c}</span></li>`;
  }).join('');
  list.querySelectorAll('.s-item').forEach(it => it.addEventListener('click', () => selectSeries(it.dataset.id)));
  selectSeries(SERIES[0].id);
}

function selectSeries(id) {
  const s = SERIES.find(x => x.id === id);
  $$('#seriesList .s-item').forEach(it => it.classList.toggle('is-active', it.dataset.id === id));
  $('#seriesEyebrow').textContent = 'MODEL SERIES · 当前系列';
  $('#seriesTitle').textContent = s.name;
  $('#seriesDesc').textContent = s.desc;
  const ms = bySeries(id);
  $('#seriesCount').textContent = `${ms.length} 个版本`;
  const grid = $('#versionGrid');
  grid.innerHTML = ms.map(m => {
    const badge = m.tag ? (m.tag === '热门' ? '<span class="badge hot">热门</span>' : m.tag === '最新' ? '<span class="badge new">最新</span>' : `<span class="badge">${m.tag}</span>`) : '';
    const save = m.savePct ? `<span class="mono">省 ${m.savePct}%</span>` : '';
    return `<div class="v-card" data-id="${m.id}" tabindex="0" role="button">
      <span class="v-more" aria-hidden="true">→</span>
      <div class="v-name">${esc(m.name)}</div>
      <div class="v-badges">${badge}</div>
      <div class="v-meta">${save}<span class="mono">官方 ¥${m.offIn} / 1M</span></div>
    </div>`;
  }).join('');
  grid.querySelectorAll('.v-card').forEach(c => {
    c.addEventListener('click', () => openDetail(c.dataset.id));
    c.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openDetail(c.dataset.id); } });
  });
}

/* 打开三级详情 */
function openDetail(id) {
  const m = MODELS.find(x => x.id === id);
  if (!m) return;
  curModelId = id;
  const s = SERIES.find(x => x.id === m.series);
  const docs = docsFor(m, m.docs);
  const saveAmt = ((m.offIn * 1000 + m.offOut * 2000) - (m.parIn * 1000 + m.parOut * 2000)) / 1000; /* 示例差 */
  const badgeHtml = m.tag ? (m.tag === '热门' ? '<span class="badge hot">热门</span>' : m.tag === '最新' ? '<span class="badge new">最新</span>' : `<span class="badge">${m.tag}</span>`) : '';

  $('#detailMount').innerHTML = `
    <div class="crumb">
      <button class="back" type="button" data-go="series"><i class="chev-l">‹</i>返回</button>
      <span class="crumb-path mono">大模型 / <button class="linklike" id="crumbSeries">${s.name}</button> / <b>${m.name}</b></span>
    </div>

    <div class="d-head">
      <div>
        <p class="eyebrow mono">MODEL VERSION · ${s.name.toUpperCase()}</p>
        <h1 class="d-title"><span class="series">${s.name}</span> · ${esc(m.name)}</h1>
        <div class="d-badges">${badgeHtml}<span class="badge">${m.firm} 供货</span></div>
      </div>
      <div class="doc-count mono dim" style="font-size:12px">更新于 2026.09.04</div>
    </div>

    <div class="d-block">
      <h3>模型介绍</h3>
      <p class="d-desc">${esc(m.desc)}</p>
    </div>

    <div class="d-block">
      <h3>市场地位</h3>
      <div class="spot"><span class="q">“</span><span>${esc(m.market)}</span></div>
    </div>

    <div class="d-block">
      <h3>当前合作厂商</h3>
      <div class="firm">
        <div class="firm-logo">${m.firmIco}</div>
        <div class="firm-txt">已合作:${m.firm}<small>协议有效期至 2026.12.31 · 最近报价 2026.09.01</small></div>
        <span class="badge" style="margin-left:auto">合作中</span>
      </div>
    </div>

    <div class="d-block">
      <h3>价格对比</h3>
      <div class="price-grid">
        <div class="price-card pc-official">
          <span class="p-tag">官方价格 · 刊例价</span>
          <div class="p-row"><span class="p-amt mono">${m.offIn}</span><span class="p-cur">¥</span><span class="p-per">/ 百万 Tokens(输入)</span></div>
          <div class="p-row" style="margin-top:4px"><span class="p-amt mono" style="font-size:22px">${m.offOut}</span><span class="p-cur" style="font-size:13px">¥</span><span class="p-per" style="font-size:11px">/ 百万 Tokens(输出)</span></div>
          <span class="p-save">官方直购 · 无阶梯</span>
        </div>
        <div class="price-card pc-partner">
          <span class="p-tag">合作商报价 · 协议价</span>
          <div class="p-row"><span class="p-amt mono">${m.parIn}</span><span class="p-cur">¥</span><span class="p-per">/ 百万 Tokens(输入)</span></div>
          <div class="p-row" style="margin-top:4px"><span class="p-amt mono" style="font-size:22px">${m.parOut}</span><span class="p-cur" style="font-size:13px">¥</span><span class="p-per" style="font-size:11px">/ 百万 Tokens(输出)</span></div>
          <span class="p-save green">协议价 · 含阶梯</span>
        </div>
      </div>
      <div class="save-banner">
        <span class="lb">同比官网节省</span>
        <span class="amt mono">${m.savePct}%</span>
        <span class="pct">按当前用量口径估算</span>
      </div>
    </div>

    <div class="d-block">
      <h3>最近报价文档</h3>
      <ul class="doc-list">
        ${docs.map(d => `<li class="doc-row">
          <span class="doc-ic">📄</span>
          <div><div class="doc-name">${esc(d.name)}</div><div class="doc-date">${d.date} · ${d.src}</div></div>
          <button class="doc-go" type="button" data-doc="${esc(d.name)}">查看</button>
        </li>`).join('')}
      </ul>
    </div>

    <div class="d-block usage">
      <div class="usage-head">
        <h3 style="margin-bottom:0">公司使用量看板</h3>
        <div class="usage-badges">
          <button class="ub is-active" type="button" data-span="30">近30天</button>
          <button class="ub" type="button" data-span="90">近90天</button>
          <button class="ub" type="button" data-span="180">近180天</button>
        </div>
      </div>
      <div id="usageMount"></div>
    </div>`;

  /* 动态绑定详情内事件 */
  const mount = $('#detailMount');
  mount.querySelectorAll('.back').forEach(b => b.addEventListener('click', () => showView('series')));
  const crumb = mount.querySelector('#crumbSeries');
  if (crumb) crumb.addEventListener('click', () => showView('series'));
  mount.querySelectorAll('.doc-go').forEach(b => b.addEventListener('click', () => toast(`打开报价文档:${b.dataset.doc}(原型演示)`)));
  mount.querySelectorAll('.ub').forEach(b => b.addEventListener('click', () => {
    mount.querySelectorAll('.ub').forEach(x => x.classList.remove('is-active'));
    b.classList.add('is-active');
    renderUsage(m, b.dataset.span);
  }));

  renderUsage(m, 30);
  showView('detail');
  /* 覆盖层内滚动归顶(showView 内已处理),底层页面不滚动 */
}

/* 使用量看板渲染(占位图表:柱状 + 环形 + 排行) */
function renderUsage(m, span) {
  const u = usageFor(m);
  const days = span === 30 ? 30 : span === 90 ? 90 : 180;
  const cnt = Math.min(days, 30);
  const slice = u.calls.slice(-cnt); /* 取最近 cnt 天 */
  const max = Math.max(...slice) * 1.15;
  const totCalls = Math.round(u.calls.reduce((a, b) => a + b, 0) * (days / u.days));
  const totToks = Math.round((u.toks.reduce((a, b) => a + b, 0) * (days / u.days)) / 1000); /* 亿 */
  const trendUp = ((u.calls[u.calls.length - 1] / u.calls[u.calls.length - 6]) - 1) * 100;

  const barsHtml = slice.map((v, i) => {
    const h = Math.max(6, (v / max) * 100);
    const hl = i === slice.length - 1 ? ' hl' : '';
    return `<div class="bar${hl}" style="height:${h}%"><span class="bar-v">${fmt(v)}</span></div>`;
  }).join('');
  const barXHtml = slice.map((v, i) => {
    const lbl = cnt <= 31 ? `${i + 1}日` : `${Math.round((i + 1) * days / slice.length)}日`;
    return `<span>${lbl}</span>`;
  }).join('');

  const health = [
    { k: '可用性', v: '99.92%', w: 99.92 },
    { k: '缓存命中', v: '34%', w: 34 },
    { k: '错误率', v: '0.12%', w: 0.12 },
  ];

  $('#usageMount').innerHTML = `
    <div class="usage-metrics">
      <div class="metric"><span class="m-label">调用次数 <span class="m-delta up mono">↑ ${trendUp.toFixed(1)}%</span></span><div class="m-val mono">${fmt(totCalls)}</div></div>
      <div class="metric"><span class="m-label">Token 消耗</span><div class="m-val mono">${fmt(totToks)} 亿</div></div>
      <div class="metric"><span class="m-label">活跃用户数 <span class="m-delta up mono">↑ 8.2%</span></span><div class="m-val mono">${fmt(u.users)}</div></div>
    </div>
    <div class="chart-grid">
      <div class="chart-box">
        <h4>调用量趋势(近${days}天)</h4>
        <div class="bars">${barsHtml}</div>
        <div class="bar-x">${barXHtml}</div>
      </div>
      <div class="chart-box">
        <h4>Token 结构(近30天)</h4>
        <div style="display:flex;align-items:center">
          <div class="donut-ring"><div class="ring-bg"></div><div class="ring-lb"><b>67%</b>输入 Tokens<br>按量占比</div></div>
          <ul class="donut-legend">
            <li><i style="background:var(--blk-2)"></i>输入 Tokens<span class="mono">≈67%</span></li>
            <li><i style="background:#e5e7ea"></i>输出 Tokens<span class="mono">≈33%</span></li>
          </ul>
        </div>
      </div>
    </div>
    <div style="display:flex;gap:14px;margin-top:14px">
      <div class="chart-box" style="flex:1">
        <h4>内部调用方排行(按调用量)</h4>
        <ul class="rank-list">
          ${[['智能客服', .62], ['代码助手', .48], ['数据分析', .31], ['内容生成', .22], ['内部问答', .14]].map((r, i) => `
          <li class="rank-item"><span class="r-pos">${i + 1}</span><span class="r-name">${r[0]}</span><span class="r-bar"><i style="width:${r[1] * 100}%"></i></span><span class="mono" style="font-size:11px;color:var(--ink-3)">${Math.round(r[1] * 100)}%</span></li>`).join('')}
        </ul>
      </div>
      <div class="chart-box" style="flex:0 0 300px">
        <h4>模型健康度</h4>
        <div style="display:flex;gap:10px;flex-direction:column">
          ${health.map(h => `
            <div class="rank-item"><span class="r-name" style="flex-basis:64px">${h.k}</span><span class="r-bar"><i style="width:${Math.max(2, h.w)}%"></i></span><span class="mono" style="font-size:11px;color:var(--ink-2)">${h.v}</span></div>`).join('')}
          <div class="rank-item"><span class="r-name" style="flex-basis:64px">P95 延迟</span><span class="r-bar"><i style="width:64%"></i></span><span class="mono" style="font-size:11px;color:var(--ink-2)">1.8s</span></div>
        </div>
      </div>
    </div>`;
}

/* ═══════════════════════════════════════════════
   板块二 · 项目日志(iOS 风格卡片)
   ═══════════════════════════════════════════════ */
/* AI 今日摘要 */
const aiSummary = {
  title: 'AI 今日摘要',
  newCount: 4,
  summaryText: '重点推进 DeepSeek-V4 商务条款复议，GPT-5 价格回调预警已同步。',
  trendUp: 12,
  rawDetails: [
    { time: '10:30', txt: '李敏(商务组)—— 收到 Claude 厂商返稿,条款无异议,进入盖章流程。' },
    { time: '11:12', txt: '张凯(商务组)—— DeepSeek-V4 价格复议申请已递交,预计本周内出结果。' },
    { time: '14:05', txt: '王工(技术组)—— DeepSeek-V4 接口压测完成,并发表现超预期。' },
    { time: '16:40', txt: '赵雪(财务)—— GPT-5 预付款申请单已提交审批。' },
  ],
};

function renderAi() {
  $('#aiBadge').textContent = `+${aiSummary.newCount} 新增`;
  $('#aiText').textContent = aiSummary.summaryText;
  $('#aiTrend').innerHTML = `↗ 较昨日提升 ${aiSummary.trendUp}%`;
  $('#aiRaw').innerHTML = aiSummary.rawDetails.map(r =>
    `<div class="raw-row"><span class="r-time">${r.time}</span><span class="r-txt">${esc(r.txt)}</span></div>`).join('');
}
$('#aiSum').addEventListener('click', e => {
  if (e.target.closest('.ai-raw')) return;
  const open = $('#aiSum').classList.toggle('open');
  $('#aiSum').setAttribute('aria-expanded', String(open));
});
renderAi();

/* 日志数据:按天倒序,今天是第 32 天(2026.09.05 周六) */
const LOG_DAYS = [
  {
    date: new Date(2026, 8, 5), dayNo: 32, status: 'g', statusTxt: '顺利', isToday: true,
    entries: [
      { avatar: '商', dept: '商务组', name: '李敏', time: '10:30', txt: '收到 Claude 厂商返稿,条款无异议,进入盖章流程。' },
      { avatar: '技', dept: '技术组', name: '王工', time: '14:20', txt: 'DeepSeek-V4 接口压测完成,并发表现优异 <span class="hl">(超预期 15%)</span>' },
      { avatar: '财', dept: '财务', name: '赵雪', time: '16:05', txt: 'GPT-5 预付款申请单已提交审批。' },
    ],
  },
  {
    date: new Date(2026, 8, 4), dayNo: 31, status: 'y', statusTxt: '注意',
    entries: [
      { avatar: '商', dept: '商务组', name: '李敏', time: '09:50', txt: '发起 DeepSeek 价格复议申请,期望降低 5% 单价。' },
      { avatar: '技', dept: '技术组', name: '张伟', time: '13:40', txt: 'Claude 3.5 与现有 RAG 框架兼容性测试通过。' },
    ],
  },
  {
    date: new Date(2026, 8, 3), dayNo: 30, status: 'g', statusTxt: '顺利',
    entries: [
      { avatar: '财', dept: '财务', name: '赵雪', time: '10:05', txt: '混元 Turbo 9 月账单核对完成,无差异。' },
      { avatar: '商', dept: '商务组', name: '张凯', time: '15:30', txt: 'GLM-5.2 商务首轮报价已获取,待对比评估。' },
      { avatar: '技', dept: '技术组', name: '王工', time: '17:50', txt: 'GPT-5 上下文 128K 长文档抽取测试 <span class="hl">(通过)</span>' },
    ],
  },
  {
    date: new Date(2026, 8, 2), dayNo: 29, status: 'g', statusTxt: '顺利',
    entries: [
      { avatar: '商', dept: '商务组', name: '李敏', time: '11:15', txt: 'Claude 3.5 Opus 年度合同续签用印完成。' },
      { avatar: '技', dept: '技术组', name: '张伟', time: '16:40', txt: 'DeepSeek-V4 双活接入演练结束,回切正常。' },
    ],
  },
  {
    date: new Date(2026, 8, 1), dayNo: 28, status: 'g', statusTxt: '顺利',
    entries: [
      { avatar: '财', dept: '财务', name: '赵雪', time: '09:20', txt: '8 月各模型用量账单归档,成本环比下降 6%。' },
      { avatar: '商', dept: '商务组', name: '张凯', time: '14:10', txt: 'GPT-5 Turbo 配额增购询价已发出。' },
      { avatar: '技', dept: '技术组', name: '王工', time: '18:30', txt: '新模型评估自动化脚本上线 <span class="hl">(效率 +40%)</span>' },
    ],
  },
];

const WEEK = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
function dayLabel(d) {
  return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')} ${WEEK[d.getDay()]}`;
}
/* iOS 状态色条:g=绿 #34c759, y=橙 #ff9500, b=蓝 #007aff */
const STATUS_COLOR = { g: '#69d9ff', y: '#a78bfa', b: '#4f7cff' };

const rail = $('#rail');
let railPos = 0;
const cards = LOG_DAYS.map((d, i) => {
  const el = document.createElement('div');
  el.className = `day-card ios-card is-${d.status}`;
  el.style.setProperty('--acc-bar', STATUS_COLOR[d.status] || '#007aff');
  el.dataset.i = i;
  el.innerHTML = `
    <div class="dc-top">
      <span class="dc-day">📅 第 ${d.dayNo} 天 ${d.isToday ? '<span class="badge-new-sm">今天</span>' : ''}</span>
      <span class="dc-date">${dayLabel(d.date)}</span>
    </div>
    ${d.entries.map(e => `
      <div class="log-entry">
        <div class="avatar">${e.avatar}</div>
        <div class="log-body">
          <div class="log-meta"><span class="name">${esc(e.name)}</span><span class="dept">${e.dept}</span><span class="time mono">${e.time}</span></div>
          <div class="log-content">${e.txt}</div>
        </div>
      </div>`).join('')}
  `;
  return el;
});
rail.append(...cards);
$('#dayTotal').textContent = LOG_DAYS.length;

/* 分页圆点(iOS 胶囊长条) */
const dots = $('#dots');
LOG_DAYS.forEach((d, i) => {
  const b = document.createElement('button');
  b.className = 'dot' + (i === railPos ? ' is-active' : '');
  b.type = 'button';
  b.setAttribute('aria-label', `第 ${d.dayNo} 天`);
  b.addEventListener('click', () => {
    railPos = i;
    updateRail(true);
  });
  dots.appendChild(b);
});

function updateRail(snap) {
  const card = cards[railPos];
  if (!card) return;
  const target = card.offsetLeft - (rail.clientWidth - card.offsetWidth) / 2;
  rail.scrollTo({ left: target, behavior: snap ? 'smooth' : 'auto' });
  $$('#dots .dot').forEach((d, i) => d.classList.toggle('is-active', i === railPos));
  const last = railPos === LOG_DAYS.length - 1;
  const first = railPos === 0;
  $('#railPrev').disabled = first;
  $('#railNext').disabled = last;
}
$('#railPrev').addEventListener('click', () => { if (railPos > 0) { railPos--; updateRail(true); } });
$('#railNext').addEventListener('click', () => { if (railPos < LOG_DAYS.length - 1) { railPos++; updateRail(true); } });

/* 鼠标拖拽滑动 */
let isDown = false, startX = 0, startScroll = 0;
rail.addEventListener('mousedown', e => {
  isDown = true; startX = e.pageX; startScroll = rail.scrollLeft; rail.classList.add('dragging');
});
window.addEventListener('mousemove', e => {
  if (!isDown) return;
  e.preventDefault();
  rail.scrollLeft = startScroll - (e.pageX - startX);
});
window.addEventListener('mouseup', () => {
  if (!isDown) return;
  isDown = false; rail.classList.remove('dragging');
});
/* 滑动结束按最近卡片对齐 */
let snapTimer = null;
rail.addEventListener('scroll', () => {
  clearTimeout(snapTimer);
  snapTimer = setTimeout(() => {
    const mid = rail.scrollLeft + rail.clientWidth / 2;
    let best = 0, bd = Infinity;
    cards.forEach((c, i) => {
      const d = Math.abs(c.offsetLeft + c.offsetWidth / 2 - mid);
      if (d < bd) { bd = d; best = i; }
    });
    railPos = best;
    $$('#dots .dot').forEach((d, i) => d.classList.toggle('is-active', i === railPos));
    $('#railPrev').disabled = railPos === 0;
    $('#railNext').disabled = railPos === LOG_DAYS.length - 1;
  }, 120);
}, { passive: true });

/* 点击卡片(模拟展开查看) */
cards.forEach(c => c.addEventListener('click', () => toast(`查看第 ${LOG_DAYS[+c.dataset.i].dayNo} 天完整日志(原型演示)`)));

/* 初始定位到第一天(今天) */
window.addEventListener('load', () => { railPos = 0; updateRail(false); });

/* ═══════════════════════════════════════════════
   板块三 · 测算计算器
   ═══════════════════════════════════════════════ */
const CALC_MODELS = [
  { name: 'DeepSeek-V4',   cur: '¥', offIn: 1.0, offOut: 4.0, parIn: 0.62, parOut: 2.50, savePct: 38, firm: '合作商 A', rate: 7.2 },
  { name: 'Qwen3-Max',     cur: '¥', offIn: 2.4, offOut: 9.6, parIn: 1.68, parOut: 6.72, savePct: 30, firm: '合作商 B', rate: 7.2 },
  { name: 'Doubao-1.5-Pro', cur: '¥', offIn: 0.8, offOut: 2.0, parIn: 0.52, parOut: 1.30, savePct: 35, firm: '合作商 C', rate: 7.2 },
  { name: 'ERNIE-4.5-Turbo', cur: '¥', offIn: 0.8, offOut: 2.0, parIn: 0.56, parOut: 1.40, savePct: 30, firm: '合作商 D', rate: 7.2 },
  { name: 'Hunyuan-T1',    cur: '¥', offIn: 1.0, offOut: 4.0, parIn: 0.70, parOut: 2.80, savePct: 30, firm: '合作商 E', rate: 7.2 },
  { name: 'GLM-5',         cur: '¥', offIn: 1.0, offOut: 4.0, parIn: 0.70, parOut: 2.80, savePct: 30, firm: '合作商 F', rate: 7.2 },
  { name: 'GPT-5',         cur: '$', offIn: 2.5, offOut: 10.0, parIn: 2.13, parOut: 8.50, savePct: 15, firm: '出海代理', rate: 7.2 },
  { name: 'Claude Opus 4.5', cur: '$', offIn: 4.0, offOut: 20.0, parIn: 3.40, parOut: 17.0, savePct: 15, firm: '出海代理', rate: 7.2 },
  { name: 'Claude Sonnet 4.5', cur: '$', offIn: 0.8, offOut: 4.0, parIn: 0.68, parOut: 3.40, savePct: 15, firm: '出海代理', rate: 7.2 },
];

const selModel = $('#calcModel');
selModel.innerHTML = CALC_MODELS.map(m => `<option value="${esc(m.name)}">${esc(m.name)}</option>`).join('');

/* 单位切换(请求次数 / Token数) */
let calcMode = 'req';
const zoneReq = $('#zoneReq'), zoneTok = $('#zoneTok');
$$('.mode-btn').forEach(b => b.addEventListener('click', () => {
  calcMode = b.dataset.mode;
  $$('.mode-btn').forEach(x => { const on = x === b; x.classList.toggle('is-active', on); x.setAttribute('aria-selected', String(on)); });
  zoneReq.classList.toggle('hidden', calcMode !== 'req');
  zoneTok.classList.toggle('hidden', calcMode !== 'tok');
  calcAll();
}));

/* 只读单价输入(带出) */
const chips = $('#priceChips');
function renderChips(m) {
  chips.innerHTML = `
    <span class="chip">官方输入<b class="mono">${m.cur}${m.offIn}/1M</b><span class="ck">输出 ${m.cur}${m.offOut}</span></span>
    <span class="chip"><b class="mono">${m.cur}${m.parIn}/1M</b>合作商输入<span class="ck">输出 ${m.cur}${m.parOut}</span></span>`;
}
['inpReq', 'inpTin', 'inpTout'].forEach(id => {
  $(`#${id}`).addEventListener('input', calcAll);
});
selModel.addEventListener('change', () => { renderChips(curCalcModel()); calcAll(); });
function curCalcModel() { return CALC_MODELS.find(m => m.name === selModel.value) || CALC_MODELS[0]; }

function parseNum(v) {
  const n = parseFloat(String(v).replace(/[,，\s]/g, ''));
  return isFinite(n) && n >= 0 ? n : 0;
}

/* 计算:单次成本(美元口径保留两位),月总价(人民币) */
function calcAll() {
  const m = curCalcModel();
  const usd = m.cur === '$';
  let offUnit, parUnit, offTotal, parTotal;

  const perCost = (inP, outP) => {
    if (calcMode === 'req') {
      /* 每次请求约 2000 输入 + 1000 输出 */
      const n = parseNum($('#inpReq').value);
      const single = (2000 * inP + 1000 * outP) / 1e6;
      return { unit: single, total: single * n, n };
    }
    const tin = parseNum($('#inpTin').value), tout = parseNum($('#inpTout').value);
    return { unit: 0, total: tin * inP + tout * outP, tin, tout };
  };

  const o = perCost(m.offIn, m.offOut);
  const p = perCost(m.parIn, m.parOut);

  if (usd) {
    offUnit = o.unit; parUnit = p.unit;
    offTotal = o.total * m.rate; parTotal = p.total * m.rate;
  } else {
    offUnit = o.unit; parUnit = p.unit;
    offTotal = o.total; parTotal = p.total;
  }
  const save = offTotal - parTotal;
  const savePct = offTotal > 0 ? (save / offTotal) * 100 : 0;

  if (calcMode === 'req') {
    $('#resOffUnit').textContent = `单次成本 ${usd ? '$' : '¥'}${offUnit.toFixed(2)}`;
    $('#resParUnit').textContent = `单次成本 ${usd ? '$' : '¥'}${parUnit.toFixed(2)}`;
    $('#calcNote').textContent = `估算口径:${fmt(o.n)} 次/月 × 每次约 2K 输入 + 1K 输出 Tokens`;
  } else {
    $('#resOffUnit').textContent = `${fmt(o.tin, 1)}M 输入 + ${fmt(o.tout, 1)}M 输出`;
    $('#resParUnit').textContent = `${fmt(p.tin, 1)}M 输入 + ${fmt(p.tout, 1)}M 输出`;
    $('#calcNote').textContent = `按 ${fmt(o.tin)}M 输入 + ${fmt(o.tout)}M 输出 Tokens 计费`;
  }

  $('#resOffAmt').textContent = `${usd ? '≈¥' : '¥'}${fmt(Math.round(offTotal))}`;
  $('#resParAmt').textContent = `${usd ? '≈¥' : '¥'}${fmt(Math.round(parTotal))}`;
  $('#saveAmt').textContent = `¥${fmt(Math.round(save))}`;
  $('#savePct').textContent = savePct >= 0 ? `较官方价格降低 ${savePct.toFixed(1)}%` : '当前合作价高于官方价';

  /* 动态高亮节省幅度的视觉层级 */
  $('#saveStrip').style.opacity = save > 0 ? '1' : '.65';
}
selModel.dispatchEvent(new Event('change'));

/* ═══════════════════════════════════════════════
   抽屉 Bottom Sheet
   ═══════════════════════════════════════════════ */
const sheet = $('#sheet'), mask = $('#mask');
function openSheet() { sheet.classList.add('show'); mask.classList.add('show'); document.body.style.overflow = 'hidden'; }
function closeSheet() { sheet.classList.remove('show'); mask.classList.remove('show'); document.body.style.overflow = ''; }
$('#ruleBtn').addEventListener('click', openSheet);
$('#sheetClose').addEventListener('click', closeSheet);
mask.addEventListener('click', closeSheet);
/* 下滑关闭 */
let startY = 0, dragging = false;
const grab = $('#sheetGrab');
grab.addEventListener('touchstart', e => { startY = e.touches[0].clientY; dragging = true; }, { passive: true });
grab.addEventListener('touchmove', e => {
  if (!dragging) return;
  const dy = e.touches[0].clientY - startY;
  if (dy > 0) sheet.style.transform = `translateY(${dy * 0.6}px)`;
}, { passive: true });
grab.addEventListener('touchend', e => {
  dragging = false;
  const dy = e.changedTouches[0].clientY - startY;
  sheet.style.transform = '';
  if (dy > 90) closeSheet();
});
/* Esc 关闭 */
window.addEventListener('keydown', e => { if (e.key === 'Escape' && sheet.classList.contains('show')) closeSheet(); });

/* 初次渲染 */
renderSeries();
calcAll();

/* 滚动容器回到顶部:进入板块视图时,由滚动监听自然处理,此处补一个初次滚动定位 */
setTimeout(() => { onScroll(); }, 60);

/* ============ 数据桥：DeepSeek 采购比价（接真实数据库） ============ */
function renderDbQuotes(){
  const db = window.__DB__;
  if (!db || !db.modelBoard || !db.modelBoard.length) return;
  const board = db.modelBoard[0]; // p2 大模型采购
  const quotes = (board.quotes || []).filter(q => q.is_coef === 1);
  if (!quotes.length) return;
  const wrap = document.getElementById('dbQuotes');
  const table = document.getElementById('dbQuotesTable');
  const cnt = document.getElementById('dbQuotesCount');
  if (!wrap || !table) return;
  wrap.style.display = 'block';
  if (cnt) cnt.textContent = quotes.length + ' 条报价';
  // 按 asset 分组，组内最低标绿
  const groups = {};
  quotes.forEach(q => { if (!groups[q.asset]) groups[q.asset] = []; groups[q.asset].push(q); });
  const rows = [];
  Object.keys(groups).forEach(asset => {
    const list = groups[asset];
    const min = Math.min(...list.map(q => +q.price));
    rows.push('<div class="dbq-group"><div class="dbq-asset">' + esc(asset) + '</div>');
    list.sort((a,b) => +a.price - +b.price).forEach(q => {
      const best = +q.price === min;
      rows.push(
        '<div class="dbq-row' + (best ? ' best' : '') + '">' +
          '<span class="dbq-ch">' + esc(q.channel || '—') + '</span>' +
          '<span class="dbq-cond">' + esc(q.cond || '') + '</span>' +
          '<span class="dbq-price">' + (+q.price).toFixed(2) + ' 系数</span>' +
          (best ? '<span class="dbq-best">最优</span>' : '') +
        '</div>'
      );
    });
    rows.push('</div>');
  });
  table.innerHTML = rows.join('');
}
window.addEventListener('db-ready', renderDbQuotes);
if (window.__DB__) renderDbQuotes();
