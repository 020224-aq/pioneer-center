/**
 * 数据桥 — 让四个 iframe 板块接真实数据库
 * 逻辑：页面加载时 fetch /api/bootstrap，成功后把真实数据挂到 window.__DB__
 * 各板块渲染时优先用 window.__DB__，读不到（后端不可达）则回退内联写死数据。
 * 引入方式：在 iframe 页面的 <script src="app.js"> 之前引入本脚本。
 */
(function () {
  'use strict';

  // 防重复加载
  if (window.__DB_LOADED__) return;
  window.__DB_LOADED__ = true;
  window.__DB__ = null; // 初始为 null，表示"尚未拿到真实数据"

  function fetchDB() {
    return fetch('/api/bootstrap')
      .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(data => {
        window.__DB__ = data;
        // 通知已加载（可选：触发自定义事件，让已渲染的页面重绘）
        window.dispatchEvent(new CustomEvent('db-ready', { detail: data }));
        console.log('[data-bridge] ✅ 已从数据库加载真实数据');
        return data;
      })
      .catch(e => {
        console.warn('[data-bridge] ⚠️ 数据库不可达，回退内联数据:', e.message);
        return null;
      });
  }

  // 立即发起加载（页面初始化时并行进行）
  fetchDB();
})();
